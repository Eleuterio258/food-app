
<?php $__env->startSection('title'); ?>
<title>Vendor Dashboard | Foodzone</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<div class="col-span-5 md:col-span-4 grid gap-5 bg-blue-100 p-5 shadow">

    <?php if($notifications != 0): ?>
    <div class="bg-white text-lg">
        <div class="m-5">
            <span class="text-blue-400">You have <?php echo e($notifications); ?> new notifications</span>
            <span ><a href="/vendor-notifications" class="text-blue-400 hover:bg-blue-500 hover:text-white px-3 py-2 rounded-lg cursor-pointer">Go >></a></span>
        </div>        
    </div>    
    <?php endif; ?>

    <div class="grid grid cols-1 md:grid-cols-3 gap-5">
        <a href="http://127.0.0.1:8000/vendor-orders?status=Pending">
            <div class="text-center bg-white p-5 hover:shadow-lg">
                <p class="font-bold text-5xl mb-5 mt-5"><?php echo e($pending); ?></p>
                <p class="">Pending Orders</p>
            </div>
        </a>

        <a href="http://127.0.0.1:8000/vendor-orders?status=Processing">
            <div class="text-center bg-white p-5 hover:shadow-lg">
                <p class="font-bold text-5xl mb-5 mt-5"><?php echo e($processing); ?></p>
                <p class="">Processing Orders</p>
            </div>
        </a>

        <div class="text-center bg-white p-5 hover:shadow-lg">
            <p class="font-bold text-5xl mb-5 mt-5"><?php echo e($orders); ?></p>
            <p class="">Total Orders</p>
        </div>        
        
        <a href="http://127.0.0.1:8000/vendor-orders?status=Delivered">
            <div class="text-center bg-white p-5 hover:shadow-lg">
                <p class="font-bold text-5xl mb-5 mt-5"><?php echo e($delivered); ?></p>
                <p class="">Delivered Orders</p>
            </div>
        </a>
        
        <a href="http://127.0.0.1:8000/vendor-orders?status=Cancelled">
            <div class="text-center bg-white p-5 hover:shadow-lg">
                <p class="font-bold text-5xl mb-5 mt-5"><?php echo e($cancelled); ?></p>
                <p class="">Cancelled Orders</p>
            </div>
        </a>
        
        <div class="text-center bg-white p-5 hover:shadow-lg">
            <p class="font-bold text-5xl mb-5 mt-5"><?php echo e($items); ?></p>
            <p class="">Total Items</p>
        </div>
        <div class="text-center bg-white p-5 hover:shadow-lg">
            <p class="font-bold text-5xl mb-5 mt-5"><?php echo e($active); ?></p>
            <p class="">Active Items</p>
        </div>
        <div class="text-center bg-white p-5 hover:shadow-lg">
            <p class="font-bold text-5xl mb-5 mt-5"><?php echo e($deactivated); ?></p>
            <p class="">Deactivated Items</p>
        </div>
        <div class="text-center bg-white p-5 hover:shadow-lg">
            <p class="font-bold text-5xl mb-5 mt-5"><?php echo e($sale); ?></p>
            <p class="">Total Sale</p>
        </div>       
        
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vendor.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/vendor/dashboard.blade.php ENDPATH**/ ?>