
<?php $__env->startSection('content'); ?>


<div class="flex justify-center mt-5">
    <div class="text-center">
        <?php if($newOrders !=0): ?>
        <a href="/rider-orders">
            <div class="bg-white px-4 py-2 mb-3 rounded-lg hover:shadow-lg hover:bg-blue-500 hover:text-white">
                <p>You have <?php echo e($newOrders); ?> new orders</p>
            </div>           
        </a>
        <?php endif; ?>        

        <?php if($pickedOrders !=0): ?>
        <a href="/rider-orders">
            <div class="bg-white px-4 py-2 rounded-lg hover:shadow-lg hover:bg-green-500 hover:text-white">
                <p>You have <?php echo e($pickedOrders); ?> ongoing orders</p>
            </div>
        </a>            
        <?php endif; ?>

    </div>
    

</div>
<div class="flex justify-center">
    
    
    <div class="grid grid-cols-2 gap-10 m-5 ">
        <div class="bg-white p-10 rounded shadow text-2xl font-bold text-center">
            <p><?php echo e($deliveredOrders); ?></p>
            Delivered Orders
        </div>
        <div class="bg-white p-10 rounded shadow text-2xl font-bold text-center">
            <p><?php echo e($pickedOrders); ?></p>
            Received Orders
        </div>
        <div class="bg-white p-10 rounded shadow text-2xl font-bold text-center">
            <p><?php echo e($cancelledOrders); ?></p>
            Cancelled Orders
        </div>
        <div class="bg-white p-10 rounded shadow text-2xl font-bold text-center">
            <p><?php echo e($deliveredOrders * 40); ?></p>
            Total Earned
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.rider.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/rider/dashboard.blade.php ENDPATH**/ ?>