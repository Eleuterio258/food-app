
<?php $__env->startSection('content'); ?>
    
<div class=" mx-auto md:w-2/3 lg:w-1/2">
    <?php if(count($errors) > 0): ?>
            <div class="">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="bg-yellow-100 border border-yellow-300 px-2 py-2 mt-1 text-yellow-500 rounded"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    <form action="" method="POST">
        <?php echo csrf_field(); ?>
        <?php if($user): ?>
        <div class="bg-white mt-4  py-5 px-8 shadow rounded">
            <p class="text-xl text-center font-bold m-2">Customer Information</p>
            <div class="py-5 text-left text-gray-600">
                <label class="block font-semibold" for="customer_name">Full Name</label>
                <input type="text" name="customer_name" value="<?php echo e($user->full_name); ?>" class="border px-3 py-2 mb-2 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">

                <label class="block font-semibold" for="">Phone</label>
                <input type="phone" name="customer_phone" value="<?php echo e($user->phone); ?>"  class="border px-3 py-2 mb-2 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">

                <label class="block font-semibold" for="">City</label>
                <input type="text" name="customer_city" value="<?php echo e($user->city); ?>"  class="border px-3 py-2 mb-2 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                <label class="block font-semibold" for="">Delivery Address</label>
                <input type="text" name="customer_address" value="<?php echo e($user->address); ?>"  class="border w-full px-3 py-2 mb-2 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                
                
                
            </div>
        </div>
        <?php endif; ?>
    
        <?php echo csrf_field(); ?>
        
        <div class="bg-white mt-4 py-5 px-8 shadow rounded text-sm">
            <p class="text-xl text-center font-bold m-2">Order Information</p>
            <?php echo e($price = null); ?>

            <?php echo e($total = null); ?>

            <?php echo e($subtotal = null); ?>

            <?php echo e($quantity = null); ?>

            <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shops=>$shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="text-md font-bold">Items For <?php echo e($shops); ?> </p>
            <table class="rounded-t-lg m-5 w-full mx-auto bg-gray-200 text-gray-800 border-separate ">
                
            <tr class="text-left border-b-2 border-gray-300">
                <th class="px-4 py-3 w-2/3">Items</th>
                <th class="px-4 py-3">Qty</th>
                <th class="px-4 py-3">Price</th>
            </tr>
            
            
            
                <?php $__currentLoopData = $shop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="bg-gray-100 border-b border-gray-200 ">
                <td class="px-4 py-3 break-words"><input class="w-full bg-gray-100 focus:outline-none" readonly="readonly" type="text" name="product_name" value="<?php echo e($details['name']); ?>" ></td>
                <td class="px-4 py-3"><input class="w-full bg-gray-100 focus:outline-none" readonly="readonly" type="number" name="quantity" value="<?php echo e($details['quantity']); ?>" ></td>
                <td class="px-4 py-3"><input class="w-full bg-gray-100 focus:outline-none" readonly="readonly" type="number" name="price" value="<?php echo e($price = $details['quantity'] * $details['price']); ?>" ></td>
            </tr> 
            <?php
              $total += $details['price']* $details['quantity'];
              $subtotal += $details['price']* $details['quantity'];
              $quantity += $details['quantity'];
              //$subtotal += $total;
            
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
            <tr class="bg-gray-100 border-b border-gray-200 font-bold">
                <td class="px-4 py-3 break-words">Total</td>
                <td class="px-4 py-3 break-words"><?php echo e($quantity); ?></td>
                <td class="px-4 py-3 break-words"><input class="w-full font-bold bg-gray-100 focus:outline-none" readonly="readonly" type="number" name="total" value="<?php echo e($total); ?>" ></td>
            </tr>
            <!-- each row -->
            <?php
                $quantity = 0;
                $total=0;
            ?>
            </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <input class="font-bold text-lg bg-white" type="hidden" name="subtotal" value="<?php echo e($subtotal); ?>" >
            <p class="font-bold text-lg">Subtotal-<?php echo e($subtotal); ?> taka</p>

        </div> 
        <div class="mt-4 mb-4 flex justify-center lg:justify-end">
            <div>
                <input type="submit" name="submit" value="Place Order" class="text-white bg-red-400 hover:bg-red-500 px-4 py-2 rounded cursor-pointer">
            </div>
            
        </div> 

    </form>         
    
    
    
</div>
    



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/user/checkout.blade.php ENDPATH**/ ?>