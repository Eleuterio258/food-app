
<?php $__env->startSection('title'); ?>
<title>Foods List | Foodzone</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="col-span-5 md:col-span-4 shadow bg-white py-2">    
    <div class="w-full px-5 py-2  ">
        <p class="text-xl text-gray-600 font-semibold mb-1 ml-5">Add new item</p>
        <form action="" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4 justify-items-stretch  bg-gray-50 p-5">
                <div class="">
                    <input type="text" name="name" placeholder="Item name" class="p-2 w-full rounded border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-300 ">
                </div>
                <div>
                    <input type="number" name="price" placeholder="Price" class="p-2 w-full rounded border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-300 ">
                </div>
                <div>
                    <input type="number" name="time" placeholder="Preparation time (min)" class="p-2 w-full rounded border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-300">
                </div>
                <div>
                    <select name="category" class="p-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-blue-300 border border-gray-200 w-full">
                        <option selected disabled>Select a Category</option>
                        <option value="Appetizers">Appetizers</option>
                        <option value="Burger">Burger</option>
                        <option value="Beverage">Beverage</option>
                        <option value="Chowmein">Chowmein</option>
                        <option value="Desert">Desert</option>
                        <option value="Fries">Fries</option>
                        <option value="Meat">Meat</option>
                        <option value="Pasta">Pasta</option>
                        <option value="Pizza">Pizza</option>
                        <option value="Rice">Rice</option>
                        <option value="Salad">Salad</option>
                        <option value="Sandwitch">Sandwitch</option>
                        <option value="Soup">Soup</option>
                        <option value="Sea Food">Sea Food</option>                
                        <option value="Vegetable">Vegetable</option>
                    </select>
                </div>
                <div class="col-span-1 md:col-span-4">
                    <textarea name="details"  placeholder="Details" class="w-full p-2 rounded border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-300"></textarea>                        
                </div>
                <div>
                    <input type="file" id="image" name="image" accept="image/*" class="mb-1">
                </div>
                <div class="col-span-1 md:col-span-4">
                    <input type="submit" name="submit" value="Add Item" class="bg-blue-400 hover:bg-blue-500 text-white rounded px-3 py-2 cursor-pointer">
                </div>
            </div>
        </form>
    </div>     
        
    <?php if(count($errors) > 0): ?>
    <div class="">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="mt-1 text-red-500 "><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <?php if( session('success')): ?>
    <p class="m-1  ml-5 text-green-500 5"><?php echo e(session('success')); ?></p>
    <?php endif; ?>  
    
    
    
    
    
</div>

<div class="col-span-5 bg-gray-50 p-5">
    <p class="text-xl font-bold mb-5">My Items</p>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-5  gap-4 justify-items-center">
        <?php if(!empty($items)): ?>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class=" col-span-1 ">
            <div class="bg-white rounded shadow grid grid-rows-2 h-96 w-72 text-xs overflow-hidden">
                <div class="">
                    <img class="object-cover h-full w-full"  src="/storage/<?php echo e($item->image); ?>" alt="loading">
                </div>
                <div class="p-5">
                    <div class="flex justify-between mt-1">
                        <p class="font-bold"><?php echo e($item->name); ?></p>
                        <?php if($item->new_price != NULL): ?>
                        <div>
                            <span class="text-gray-400"><s><?php echo e($item->price); ?></s></span>
                            <span class="text-green-500"><?php echo e($item->new_price); ?> taka</span>
                        </div>
                        <?php else: ?>
                        <p><?php echo e($item->price); ?> taka</p>
                        <?php endif; ?>
                        
                    </div>
                    
                    <p>Category: <?php echo e($item->category); ?></p>
                    <p>Preparation time: <?php echo e($item->time); ?> min </p>
                    <p>Rating: <?php echo e($item->rating); ?>/5</p>
                    <p>Total <?php echo e($item->total_orders); ?> orders</p>
                    <p><?php echo e($item->details); ?></p>
                    <?php if($item->status == 'active'): ?>
                    <p class="text-green-500">  &bull;  <?php echo e($item->status); ?></p>
                    <?php else: ?>
                    <p class="text-red-500">  &bull;  <?php echo e($item->status); ?></p>
                    <?php endif; ?>
                    <div class="flex justify-between mt-2">
                        <a href="/item-details/<?php echo e($item->id); ?>" class="bg-blue-400 hover:bg-blue-500 text-white px-3 py-2 rounded-md">Edit</a>
                        <?php if($item->status == 'active'): ?>
                        <a href="/item-status/<?php echo e($item->id); ?>/deactivated" class="bg-red-400 hover:bg-red-500 text-white px-3 py-2 rounded-md">Deactive</a>
                        <?php else: ?>
                        <a href="/item-status/<?php echo e($item->id); ?>/active" class="bg-green-400 hover:bg-green-500 text-white px-3 py-2 rounded-md">Activate</a>
                        <?php endif; ?>
                    </div>
                    
                </div> 
            </div>
                
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        
    </div>
    <div class="mt-5">
        <?php echo e($items->links()); ?>

    </div>

</div>










<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vendor.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/vendor/foods.blade.php ENDPATH**/ ?>