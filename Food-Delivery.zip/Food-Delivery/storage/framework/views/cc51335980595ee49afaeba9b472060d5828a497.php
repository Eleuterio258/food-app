
<?php $__env->startSection('title'); ?>
<title>Admin Dashboard | Foodzone</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>




<div class="col-span-5 md:col-span-4 grid gap-5 bg-blue-100 p-5 shadow">
    <?php if($notifications != 0): ?>

    <div class="bg-white text-lg">
        <div class="m-5">
            <span class="text-blue-400">You have <?php echo e($notifications); ?> new notifications</span>
            <span ><a href="/notifications" class="text-blue-400 hover:bg-blue-500 hover:text-white px-3 py-2 rounded-lg cursor-pointer">Go >></a></span>
        </div>
        
    </div>
    
    <?php endif; ?>

    <div class="grid grid cols-1 md:grid-cols-3 gap-10">
        <a href="" class="bg-white p-5 hover:shadow-lg">
            <div class="text-center ">
                <p class="font-bold text-5xl mb-5 mt-5"><?php echo e($customers); ?></p>
                <p class="">Total Customers</p>
            </div>
        </a>
        <a href="" class="bg-white p-5 hover:shadow-lg">
            <div class="text-center">
                <p class="font-bold text-5xl mb-5 mt-5" ><?php echo e($vendors); ?></p>
                <p>Total Shops</p>
            </div>
        </a>
        <a href="" class="bg-white p-5 hover:shadow-lg">
            <div class="text-center">
                <p class="font-bold text-5xl mb-5 mt-5" ><?php echo e($riders); ?></p>
                <p>Total Riders</p>
            </div>
        </a>
        <a href="" class="bg-white p-5 hover:shadow-lg">
            <div class="text-center">
                <p class="font-bold text-5xl mb-5 mt-5" ><?php echo e($blockedCustomers); ?></p>
                <p>Blocked Customers</p>
            </div>
        </a>
        <a href="" class="bg-white p-5 hover:shadow-lg">
            <div class="text-center">
                <p class="font-bold text-5xl mb-5 mt-5" ><?php echo e($blockedVendors); ?></p>
                <p>Blocked Shops</p>
            </div>
        </a>
        <a href="" class="bg-white p-5 hover:shadow-lg">
            <div class="text-center">
                <p class="font-bold text-5xl mb-5 mt-5" ><?php echo e($blockedRiders); ?></p>
                <p>Blocked Riders</p>
            </div>
        </a>
        <a href="" class="bg-white p-5 hover:shadow-lg">
            <div class="text-center">
                <p class="font-bold text-5xl mb-5 mt-5" ><?php echo e($orders); ?></p>
                <p>Total Orders</p>
            </div>
        </a>
        <a href="" class="bg-white p-5 hover:shadow-lg">
            <div class="text-center">
                <p class="font-bold text-5xl mb-5 mt-5" ><?php echo e($cancelled); ?></p>
                <p>Cancelled Orders</p>
            </div>
        </a>
        <a href="" class="bg-white p-5 hover:shadow-lg">
            <div class="text-center">
                <p class="font-bold text-5xl mb-5 mt-5" ><?php echo e($delivered); ?></p>
                <p>Total Delivered Orders</p>
            </div>
        </a>
        
        
        
        
        
    </div>
    
    
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>