
<?php $__env->startSection('title'); ?>
<title>Vendors List | Foodzone</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    
    <!-- component -->
<div class="col-span-5 md:col-span-4">
    <?php if( session('success')): ?>
        <p class=" mb-2 text-green-400"><?php echo e(session('success')); ?></p>
    <?php endif; ?>
    <div class="flex md:justify-between">
        <div>
            <form method="GET" class="mb-2">
                <select name="status" class="p-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-blue-300">
                    <option value="All" selected>All</option>
                    <option value="Active">Active</option>
                    <option value="Pending">Pending</option>
                    <option value="Deactivation Pending">Deactivation Pending</option>
                    <option value="Blocked">Blocked</option>
                </select>
                <input type="submit" name="Submit" value="Filter" class="bg-blue-400 text-white hover:bg-blue-500 px-3 py-2 cursor-pointer rounded">                
            </form>
        </div>
        <div>
            <form method="GET">                
                <input type="text" name="shop_name" placeholder="Shop Name" class="p-2 focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-blue-300 rounded" required>
                <input type="submit" name="Submit" value="Search" class="bg-blue-400 text-white hover:bg-blue-500 px-3 py-2 cursor-pointer rounded">
            </form>
        </div>
    </div>
    
    
    <table class="w-full border">
        <?php if(count($shops)): ?>
        <thead>
            <tr class="bg-gray-50 border-b">
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        ID
                    </div>
                </th>
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        Email
                    </div>
                </th>
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        Full Name
                    </div>
                </th>
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        Shop Name
                    </div>
                </th>
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        Phone
                    </div>
                </th>
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        Address
                    </div>
                </th>
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        City
                    </div>
                </th>
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        Country
                    </div>
                </th>
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        Rating
                    </div>
                </th>
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        Status
                    </div>
                </th>
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        Action
                    </div>
                </th>
            </tr>
        </thead>
        <tbody> 
            <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="bg-gray-100 text-center border-b text-sm text-gray-600">
                <td class="p-2 border-r"><?php echo e($shop->id); ?></td>
                <td class="p-2 border-r"><?php echo e($shop->email); ?></td>
                <td class="p-2 border-r"><?php echo e($shop->full_name); ?></td>
                <td class="p-2 border-r"><?php echo e($shop->shop_name); ?></td>
                <td class="p-2 border-r"><?php echo e($shop->phone); ?></td>
                <td class="p-2 border-r"><?php echo e($shop->address); ?></td>
                <td class="p-2 border-r"><?php echo e($shop->city); ?></td>
                <td class="p-2 border-r"><?php echo e($shop->country); ?></td>
                <td class="p-2 border-r"><?php echo e($shop->rating); ?></td>
                <td class="p-2 border-r"><?php echo e($shop->status); ?></td>
                <td>
                    <?php if($shop->status == 'Active'): ?>
                    <a href="/block-shop/<?php echo e($shop->id); ?>" class="bg-red-400 hover:bg-red-500 p-2 text-white text-xs font-thin">Block</a>
                    <?php elseif($shop->status == 'Blocked'): ?>
                    <a href="/unblock-shop/<?php echo e($shop->id); ?>" class="bg-green-400 hover:bg-green-500 p-2 text-white text-xs font-thin">Unblock</a>                    
                    <?php elseif($shop->status == 'Deactivation Pending'): ?>
                    <a href="/block-shop/<?php echo e($shop->id); ?>" class="bg-red-400 hover:bg-red-500 p-2 text-white text-xs font-thin">Block</a>
                    <?php elseif($shop->status == 'Pending'): ?>
                    <a href="/approve-shop/<?php echo e($shop->id); ?>" class="bg-blue-400 hover:bg-blue-500 p-2 text-white text-xs font-thin">Approve</a>
                    <?php endif; ?>
                    
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
    </table>
</div>
    <?php else: ?>
    <p>No records found</p>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/admin/shops.blade.php ENDPATH**/ ?>