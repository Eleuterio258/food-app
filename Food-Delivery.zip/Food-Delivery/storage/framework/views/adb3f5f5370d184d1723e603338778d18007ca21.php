
<?php $__env->startSection('title'); ?>
<title>Riders List | Foodzone</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- component -->
<div class="col-span-5 md:col-span-4">
    <?php if( session('success')): ?>
        <p class=" mb-2 text-green-400 "><?php echo e(session('success')); ?></p>
    <?php endif; ?>
    <div class="flex md:justify-between">
        <div>
            <form method="GET" class="mb-2">
                <select name="status" placeholder="ok" class="p-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-blue-300" required>
                    
                    <option value="All" selected>All</option>
                    <option value="Active">Active</option>
                    <option value="Pending">Pending</option>
                    <option value="Deactivation Pending">Deactivation Pending</option>
                    <option value="Blocked">Blocked</option>
                </select>
                <input type="submit" name="Submit" value="Filter" class="bg-blue-400 text-white hover:bg-blue-500 px-3 py-2 cursor-pointer rounded">                
            </form>
        </div>
        <div>
            <form method="GET">                
                <input type="text" name="full_name" placeholder="Full Name" class="p-2 focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-blue-300 rounded" required>
                <input type="submit" name="Submit" value="Search" class="bg-blue-400 text-white hover:bg-blue-500 px-3 py-2 cursor-pointer rounded">
            </form>
        </div>
    </div>
    <?php if(count($riders)): ?>
    <table class="w-full border">
        <thead>
            <tr class="bg-gray-50 border-b">
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        ID
                    </div>
                </th>
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        Full Name
                    </div>
                </th>
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        Email
                    </div>
                </th>
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        Phone
                    </div>
                </th>
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        Address
                    </div>
                </th>
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        City
                    </div>
                </th>
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        NID
                    </div>
                </th>
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        Status
                    </div>
                </th>
                <th class="p-2 border-r cursor-pointer text-sm font-thin text-gray-500">
                    <div class="flex items-center justify-center">
                        Action
                    </div>
                </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $riders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="bg-gray-100 text-center border-b text-sm text-gray-600">
                <td class="p-2 border-r"><?php echo e($rider->id); ?></td>
                <td class="p-2 border-r"><?php echo e($rider->full_name); ?></td>
                <td class="p-2 border-r"><?php echo e($rider->email); ?></td>
                <td class="p-2 border-r"><?php echo e($rider->phone); ?></td>
                <td class="p-2 border-r"><?php echo e($rider->address); ?></td>
                <td class="p-2 border-r"><?php echo e($rider->city); ?></td>
                <td class="p-2 border-r"><?php echo e($rider->nid); ?></td>
                <td class="p-2 border-r"><?php echo e($rider->status); ?></td>
                <td>
                    <?php if($rider->status == 'Active'): ?>
                    <a href="/block-rider/<?php echo e($rider->id); ?>" class="bg-red-400 hover:bg-red-500 p-2 text-white text-xs font-thin">Block</a>
                    <?php elseif($rider->status == 'Deactivation Pending'): ?>
                    <a href="/block-rider/<?php echo e($rider->id); ?>" class="bg-red-400 hover:bg-red-500 p-2 text-white text-xs font-thin">Block</a>
                    <?php elseif($rider->status == 'Blocked'): ?>
                    <a href="/unblock-rider/<?php echo e($rider->id); ?>" class="bg-green-400 hover:bg-green-500 p-2 text-white text-xs font-thin">Unblock</a>
                    <?php elseif($rider->status == 'Pending'): ?>
                    <a href="/approve-rider/<?php echo e($rider->id); ?>" class="bg-blue-400 hover:bg-blue-500 p-2 text-white text-xs font-thin">Approve</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
    </table>
</div>
    <?php else: ?>
    <p>No results found.</p>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/admin/riders.blade.php ENDPATH**/ ?>