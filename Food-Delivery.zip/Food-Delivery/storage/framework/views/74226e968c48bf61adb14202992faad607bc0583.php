
<?php $__env->startSection('title'); ?>
<title>Vendor Profile | Foodzone</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="col-span-5 md:col-span-4 shadow bg-white ">
    <?php if(!empty('vendor')): ?>
    <div class="grid grid-cols-2 p-5 gap-4">
        <div class="col-span-2 lg:col-span-1 ">            
            <div class="p-10"> 
                <!--Card 1-->
                <div class="w-full 2xl:w-2/3 rounded overflow-hidden shadow-lg">
                    <?php if(!empty($vendor->image)): ?>
                    <img class="w-full h-80 " src="/storage/<?php echo e($vendor->image); ?>" alt="image loading" >
                    <?php else: ?>
                    <p class="text-3xl px-10 py-10 font-bold text-red-200">No Image</p>
                    <?php endif; ?>
                  <div class="px-6 py-4">
                    <div class="font-bold text-xl mb-2"><?php echo e($vendor->shop_name); ?></div>
                    <p class="text-gray-700 text-base">Owner : <?php echo e($vendor->full_name); ?></p>
                    <p class="text-gray-700 text-base">Email: <?php echo e($vendor->email); ?></p>
                    <?php if(!empty('user')): ?>
                    <p class="text-gray-700 text-base">Phone : <?php echo e($user->phone); ?></p>
                    <?php endif; ?>
                    <p class="text-gray-700 text-base">Street Address : <?php echo e($vendor->address); ?></p>
                    <p class="text-gray-700 text-base">City : <?php echo e($vendor->city); ?></p>
                    <p class="text-gray-700 text-base">Country : <?php echo e($vendor->country); ?></p>
                  </div>
                </div>
            </div>
            
        </div>
        <div class="col-span-2 lg:col-span-1">
            <div class="p-10 w-full  px-5 py-2  ">
                <?php if(count($errors) > 0): ?>
                    <div class="">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="bg-yellow-100 border border-yellow-300 px-2 py-2 mt-1 text-yellow-500 rounded"><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?> 
                <?php if( session('success')): ?>
                <p class="m-1  ml-5 text-green-500 5"><?php echo e(session('success')); ?></p>
                <?php endif; ?>   
                <div class="text-center">
                    <span class="text-2xl font-bold text-gray-800 ">Update Information</span>
                    <div class="mt-5 bg-white py-5 px-5 text-md bg-gray-50 shadow">
                        <form action="" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="w-full py-5 gap-4 grid grid-cols-1 xl:grid-cols-2  lg:justify-items-center text-gray-600 text-left">
                                <div class="w-full ">
                                    <label class="block font-semibold">Full Name</label>
                                    <input type="text" name="full_name" value="<?php echo e($vendor->full_name); ?>" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                                </div>
                                <div class="w-full ">
                                    <label class="block font-semibold ">Email</label>
                                    <input type="email" name="email" value="<?php echo e($vendor->email); ?>" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                                </div>
                                <div class="w-full ">
                                    <label class="block  font-semibold">Phone</label>
                                    <input type="phone" name="phone" value="<?php echo e($user->phone); ?>" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                                </div>
                                <div class="w-full ">
                                    <label class="block  font-semibold">Shop Name</label>
                                    <input type="text" name="shop_name" value="<?php echo e($vendor->shop_name); ?>"  class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                                </div>
                                <div class="w-full ">
                                    <label class="block  font-semibold">Address</label>
                                    <input type="text" name="address" value="<?php echo e($vendor->address); ?>"  class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                                </div>
                                <div class="w-full ">
                                    <label class="block  font-semibold">City</label>
                                    <input type="text" name="city" value= "<?php echo e($vendor->city); ?>"  class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                                </div>
                                <div class="w-full ">
                                    <label class="block  font-semibold">Password</label>
                                    <input type="password" name="password"  value = "<?php echo e($user->password); ?>"  class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                                </div>
                                <div class="border w-full p-2 mt-3 rounded ">
                                    <input type="file" id="image" name="image" accept="image/*" class="mb-1">
                                </div>
                            </div>
                            <div class="w-full flex justify-around">
                                <div>
                                    <button type="submit" class="bg-red-400 w-full px-8 py-3 text-sm shadow-sm font-medium border text-white rounded-md hover:shadow-lg hover:bg-red-500 focus:outline-none">Update</button> 
                                </div>                                        
                            </div>
                            
                        </form>    
                    </div>
                    
                </div>
               <div class="py-5 text-red-400">
                   <?php if($vendor->status == "Deactivation Pending"): ?>
                   <div>
                    <span class="">You have a Deactivation request pending</span> <span><a href="/vendor-activate" class="bg-red-300 text-white hover:bg-red-500 hover:text-white p-2 rounded mt-3">Cancel</a></span>
                   </div>
                   
                   
                   <?php else: ?>
                   <a href="/vendor-deactivate" class="hover:bg-red-500 hover:text-white p-2 rounded">Deactivate Shop</a>
                   <?php endif; ?>
               </div>
               <?php endif; ?>
            </div>
        </div>
    </div>
    
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vendor.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/vendor/shop.blade.php ENDPATH**/ ?>