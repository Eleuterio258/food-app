
<?php $__env->startSection('title'); ?>
<title>Notifications | Foodzone</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<div class="col-span-5 md:col-span-4">
    <?php if($notifications): ?>
        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="bg-white p-2 m-2  rounded shadow">
            <div class="flex justify-between">
                <div>
                    <span ><?php echo e($notification->message); ?> from</span> <span class="text-blue-400"><?php echo e($notification->from); ?></span>
                </div>
                <div>
                    
                    <span><?php echo e($notification->created_at->diffForHumans()); ?></span>
                </div>
                

            </div>
            
            
        </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>

</div>  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vendor.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/vendor/notifications.blade.php ENDPATH**/ ?>