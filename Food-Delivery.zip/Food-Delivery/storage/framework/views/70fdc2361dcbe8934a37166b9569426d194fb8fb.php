
<?php $__env->startSection('content'); ?>




<div class="flex justify-center "> 
       
    <div class="bg-gray-200 sm:w-full md:1/2 lg:w-1/3 m-10 p-5 shadow-lg">
        
        <?php if(count($orders)): ?>
        <p class="text-xl">Order History</p>       
        <div >
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="/rider-order/<?php echo e($order->id); ?>">
            <div class="bg-white rounded p-4 shadow mb-4">
                
                <div class=" p-2">
                    <div class="flex justify-start border-dashed text-xs text-gray-600">
                        <p>Order ID #<?php echo e($order->id); ?></p>                       
                    </div>
                    <div class="flex justify-between border-dashed border-b border-gray-300 text-lg font-bold text-gray-600">
                        <p><?php echo e($order->shop_name); ?></p>
                        <p class="text-gray-400 text-xl font-bold">Delivered</p>
                        
                    </div>                    
                    <div class="flex justify-between">
                        <p><?php echo e($order->shipping); ?></p>
                        <p><?php echo e($order->sub_total); ?> (<?php echo e($order->payment_status); ?>)</p>
                    </div>                                                        
                </div>
                
            </div>
            </a>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            
        </div>
        <?php else: ?>
            <p class="mt-10 font-bold text-xl">No History Available</p>
        <?php endif; ?>   
        
    </div>
</div>



<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.rider.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/rider/history.blade.php ENDPATH**/ ?>