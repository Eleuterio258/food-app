<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo $__env->yieldContent('title'); ?>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    
</head>

<body class="text-gray-600 bg-gray-100 ">
    <nav class="bg-white">        
        <div class="">
            <div class="">
                <div class="flex justify-center bg-white p-5 px-10 font-bold">                   
                    <a href="/"><span class=" text-gray-900 font-bold text-3xl">Foodzone</span></a>
                </div>
            </div>                                
        </div>
    </nav>


    <div class="grid md:grid-cols-5 gap-10 mx-10 my-5 ">

        <div class="col-span-5 md:col-span-1  ">
            <div class="bg-white grid grid-cols-1 divide-y divide-light-blue-400 shadow">
                <div class="py-3 flex justify-center text-xl ">
                    <p>Shop Name</p>
                </div>
                <div class="flex justify-start p-3 ml-3 mr-3 hover:bg-blue-400 hover:text-white ">
                    <a href="/">Dashboard</a>
                </div>
                <div class="flex justify-start p-3 ml-3 mr-3 hover:bg-blue-400 hover:text-white ">
                    <a href="/vendor-notifications">Notification</a>
                </div>
                <div class="flex justify-start p-3 ml-3 mr-3 hover:bg-blue-400 hover:text-white ">
                    <a href="/vendor-orders">Orders</a>
                </div>
                <div class="flex justify-start p-3 ml-3 mr-3 hover:bg-blue-400 hover:text-white ">
                    <a href="/vendor-shop">My Shop</a>
                </div>
                <div class="flex justify-start p-3 ml-3 mr-3 hover:bg-blue-400 hover:text-white ">
                    <a href="/vendor-foods">Items</a>
                </div>
                <div class="flex justify-start p-3 ml-3 mr-3 mb-2 hover:bg-blue-400 hover:text-white ">
                    <a href="/logout">Logout</a>
                </div>
            </div>        
        </div>
        
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</body>
</html><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/layouts/vendor/layout.blade.php ENDPATH**/ ?>