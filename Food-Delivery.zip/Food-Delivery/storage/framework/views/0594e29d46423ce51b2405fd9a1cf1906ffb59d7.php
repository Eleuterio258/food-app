
<?php $__env->startSection('content'); ?>




<div class="flex justify-center"> 
    <div class=" sm:w-full md:1/2 lg:w-1/3 m-10 p-5 shadow-lg">
        <div class="">
            <div class="flex md:justify-end">
                <div>
                    <form method="GET">                
                        <input type="text" name="address" placeholder="Location" class="p-2 focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-blue-300 rounded" required>
                        <input type="submit" name="Submit" value="Search" class="bg-blue-400 text-white hover:bg-blue-500 px-3 py-2 cursor-pointer rounded">
                    </form>
                </div>
            </div>
        </div>
        <?php if(count($pickedOrder)): ?>
        <p class="text-xl mb-2 mt-2">Picked Orders</p>       
        <div >
            <?php $__currentLoopData = $pickedOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="/rider-order/<?php echo e($order->id); ?>">
            <div class="bg-white rounded p-4 shadow mb-4">
                
                <div class=" p-2">
                    <div class="flex justify-start border-dashed text-xs text-gray-600">
                        <p>Order ID #<?php echo e($order->id); ?></p>                       
                    </div>
                    <div class="flex justify-between border-dashed border-b border-gray-300 text-lg font-bold text-gray-600">
                        <p><?php echo e($order->shop_name); ?> (<?php echo e($order->address); ?>)</p>
                        <p class="text-base font-normal"><?php echo e($order->status); ?></p>
                        
                    </div>                    
                    <div class="flex justify-between">
                        <p><?php echo e($order->shipping); ?></p>
                        <p><?php echo e($order->sub_total); ?> (<?php echo e($order->payment_status); ?>)</p>
                    </div>                                                        
                </div>
                
            </div>
            </a>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            
        </div>
        <?php endif; ?>


        <?php if(count($newOrders)): ?>            
        <div >
            <p class="text-xl mb-2 mt-2">Available Orders</p>
            <?php $__currentLoopData = $newOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="/rider-order/<?php echo e($order->id); ?>">
            <div class="bg-white rounded p-4 shadow mb-4">
                
                <div class=" p-2">
                    <div class="flex justify-start border-dashed text-xs text-gray-600">
                        <p>Order ID #<?php echo e($order->id); ?></p>                       
                    </div>
                    <div class="flex justify-between border-dashed border-b border-gray-300 text-lg font-bold text-gray-600">
                        <p><?php echo e($order->shop_name); ?> (<?php echo e($order->address); ?>)</p>
                        <p class="text-green-400 text-xl font-bold">Available</p>
                        
                    </div>                    
                    <div class="flex justify-between">
                        <p><?php echo e($order->shipping); ?></p>
                        <p><?php echo e($order->sub_total); ?> (<?php echo e($order->payment_status); ?>)</p>
                    </div>                                                        
                </div>
                
            </div>
            </a>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            
        </div>
        <?php else: ?>
        <div class="text-center">
            <p class="mt-2 font-bold text-xl text-gray-400">No New Orders Available</p>
        </div>            
        <?php endif; ?>
    </div>
</div>
    




<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.rider.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/rider/orders.blade.php ENDPATH**/ ?>