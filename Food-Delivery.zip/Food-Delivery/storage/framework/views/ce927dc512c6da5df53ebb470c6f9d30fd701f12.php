
<?php $__env->startSection('title'); ?>
<title>Invoice | Foodzone</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if($order): ?>

<?php if( session('success')): ?>
<div class="flex justify-center mt-2">
    <p class="mb-2 text-green-400 "><?php echo e(session('success')); ?></p>
</div>
    
<?php endif; ?>
<div class="col-span-5 md:col-span-4">
    <div class="flex justify-center mt-2">
        <div>
            <a href="/vendor-orders" class="text-blue-400 hover:bg-blue-500 hover:text-white px-3 py-2 rounded">back to all orders</a><br>
        </div>    
    </div>
    <div class="">
        
        <div class=" flex justify-center mt-2">
            <div class="flex justify-center w-full lg:w-4/5 text-xs lg:text-base min-h-screen">
                <div class="bg-white shadow p-10 w-full md:w-4/5 h-full">
                    <h3 class="text-2xl font-bold">Order Information</h3>                    
                    <div class="">
                        
                        <div class="flex justify-between mb-5">
                            <div>
                                <p>Order Number #<?php echo e($order->id); ?></p>
                                <p>Order Status: <?php echo e(ucFirst($order->status)); ?></p>
                            </div>
                            <div>
                                <p>Date: <?php echo e($order->created_at); ?></p>
                            </div>
                                                    
                            
                        </div>
                        <div class="flex justify-between mb-5">
                            <div  class="">
                                <p class="font-bold">Bill To</p>
                                <span class="font-bold">Name:</span> <span><?php echo e($order->customer_name); ?></span> <br>
                                <span class="font-bold">Address:</span> <span><?php echo e($order->shipping); ?></span><br>
                                <span class="font-bold">City:</span> <span><?php echo e($order->city); ?></span><br>
                                <span class="font-bold">Phone:</span> <span><?php echo e($order->phone); ?></span><br>
                            </div>
                            <div class="">
                                <p class="font-bold">Bill From</p>
                                <p><?php echo e($order->shop_name); ?></p>
                            </div>
                        </div>
                        <div class="mb-5">
                            <p class="font-bold mb-2">Description</p>
                            <table class="table-fixed w-full text-left ">
                                <tr class="border">
                                    <th class="w-1/2 p-1">Item</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                </tr>
                                
                                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="border">
                                    <td class="p-1"><?php echo e($order->items[$items]['name']); ?></td>  
                                    <td class="p-1"><?php echo e($order->items[$items]['quantity']); ?></td>                         
                                    <td class="p-1"><?php echo e($order->items[$items]['price']); ?> </td>  
                                </tr>                       
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                            </table>
                        </div>
                        <div class="mt-5">
                            <p class="text-xl lg:text-2xl">Total: <?php echo e($order->sub_total); ?> taka</p>
                            <span >Payment Status: </span> <span class="text-red-400"><?php echo e($order->payment_status); ?></span> <br>
                            
                        </div>
                    </div> 
                
            </div>
        </div>
    
           
    </div>
    <?php else: ?>
        <div class="text-center mt-10 bg-red-100 p-2">
            <p class="text-3xl bg-white p-5">No Orders Found</p>
        </div>        
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vendor.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/vendor/order.blade.php ENDPATH**/ ?>