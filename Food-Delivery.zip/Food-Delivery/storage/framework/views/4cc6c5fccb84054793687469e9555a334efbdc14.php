
<?php $__env->startSection('title'); ?>
<title>Shops | Foodzone</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<main class="px-40 py-6">
    <div>
        <h4 class="font-bold mt-2 pb-2 border-b border-gray-300">All Shops</h4>
        <div class="mt-8 grid md:grid-cols-4 gap-10">
            <?php if($shops): ?>
            <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!--card-->
            <div class="bg-white rounded-md overflow-hidden shadow-md">
                <a href="/shops/<?php echo e($shop->id); ?>">
                    <?php if($shop->image): ?>
                    <img src="storage/<?php echo e($shop->image); ?>" alt="image loading" class="w-full h-32 sm:h-48 object-cover">
                    <?php else: ?>
                    <div class="w-full h-32 sm:h-48 p-5" >
                        <p class="text-2xl font-bold text-gray-300">No Image</p>
                    </div>
                    <?php endif; ?>
                    <div class="m-4">
                        <span class="font-bold"><?php echo e($shop->shop_name); ?></span>
                        <span class="text-sm">(<?php echo e($shop->rating); ?>/5)</span>
                        <span class="block text-gray-500 text-sm"><?php echo e($shop->address); ?></span>
                    </div> 
                </a>                    
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            
        </div>
        <div class="mt-5">
            <?php echo e($shops->links()); ?>

        </div>
        
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/shops.blade.php ENDPATH**/ ?>