
<?php $__env->startSection('title'); ?>
<title>Orders | Foodzone</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="col-span-5 md:col-span-4 grid gap-5 ">
    <div>
        <?php if(count($orders)): ?>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
                <div class="bg-white rounded p-4 shadow mb-4">
                    <a href="/order/<?php echo e($order->id); ?>">
                        
                        <div class=" p-2">
                            <div class="flex justify-between border-dashed text-xs text-gray-600">
                                <p>Order ID #<?php echo e($order->id); ?></p>                       
                                <p>Placed on-<?php echo e($order->created_at); ?></p>                       
                            </div>
                            <div class="flex justify-between border-dashed border-b border-gray-300 text-lg font-bold text-gray-600">
                                <p><?php echo e($order->shop_name); ?></p>
                                <p class="text-sm font-normal"><?php echo e($order->status); ?></p>
                                
                            </div>                    
                            <div class="flex justify-between">
                                <p><?php echo e($order->shipping); ?></p>
                                <p><?php echo e($order->sub_total); ?> (<?php echo e($order->payment_status); ?>)</p>
                            </div>                                                        
                        </div>
                    </a>            
                </div>            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <div class="mt-5">
            <?php echo e($orders->links()); ?>

        </div> 
        
    </div>
       
    
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/admin/orders.blade.php ENDPATH**/ ?>