<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foodzone</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    
</head>

<body class="text-gray-600 bg-gray-100">
    <nav class="bg-white">        
        <div class="">

           <div class="flex justify-center pt-5">
                <a href="<?php echo e("/"); ?>"><span class="ml-3 text-gray-900 font-bold text-3xl hover:text-blue-500">Foodzone</span></a>
            </div> 

            <div class="flex justify-center ">
                <div class="flex flex-row md:w-1/3 md:justify-around bg-white p-5 ">                   
                    <a class="hover:bg-blue-400 hover:text-white px-4 py-2 rounded" href="/rider-orders">Orders</a>
                    <a class="hover:bg-blue-400 hover:text-white px-4 py-2 rounded" href="/rider-profile">Profile</a>
                    <a class="hover:bg-blue-400 hover:text-white px-4 py-2 rounded" href="/rider-history">History</a>
                    <a class="hover:bg-blue-400 hover:text-white px-4 py-2 rounded" href="/logout">Logout</a>
                </div>
            </div>                                
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

</body>
</html><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/layouts/rider/layout.blade.php ENDPATH**/ ?>