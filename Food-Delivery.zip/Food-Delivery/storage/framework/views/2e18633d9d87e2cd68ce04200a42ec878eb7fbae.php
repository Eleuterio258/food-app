<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo $__env->yieldContent('title'); ?>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    
</head>
<body class="text-gray-600 bg-gray-100">
    <nav class="bg-white">        
        <div class="container mx-auto flex flex-wrap p-5  flex-col md:flex-row items-center">                
            <a href="<?php echo e("/"); ?>"><span class="ml-3 text-gray-900 font-bold text-3xl">Foodzone</span></a>
            <div class="font-bold md:ml-auto md:mr-auto flex flex-wrap items-center text-base justify-center">
                <a class="ml-10 text-sm hover:text-red-500" href="<?php echo e("/"); ?>">HOME</a>
                <a class="ml-10 text-sm hover:text-red-500" href=<?php echo e("/foods"); ?>>FOODS</a>
                <a class="ml-10 text-sm hover:text-red-500" href="<?php echo e("/shops"); ?>">SHOPS</a>
                <a class="ml-10 text-sm hover:text-red-500" href="#">CONTACT</a>
            </div>
            
            
            <div class="space-x-1">
                <?php if(!session('cart')): ?>               
                <button class="bg-grey-light hover:bg-grey text-grey-darkest font-semibold px-5 py-3 rounded focus:outline-none cursor:pointer">
                    <svg class="w-6 h-6 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                    <span>Cart</span>
                </button>
                
                <?php else: ?>
                <a href="/cart">
                    <button class="hover:text-red-500 text-red-400 font-bold font-semibold px-5 py-3 rounded focus:outline-none cursor:pointer">
                        <svg class="w-6 h-6 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                        <span>Cart</span>
                    </button>
                </a>
                <?php endif; ?>
                <?php if(session('user_type')): ?>
                <button class="bg-red-400 px-5 py-3 text-sm shadow-sm font-medium border text-white rounded-full hover:shadow-lg hover:bg-red-500 focus:outline-none"><a href=<?php echo e("/logout"); ?>>Logout</a></button> 
                <a class="text-sm font-medium text-grey-darkest font-semibold hover:text-red-500" href=<?php echo e("/user-orders"); ?>>My Account</a> 
                <?php else: ?>
                <button class="bg-red-400 px-5 py-3 text-sm shadow-sm font-medium border text-white rounded-full hover:shadow-lg hover:bg-red-500 focus:outline-none"><a href=<?php echo e("/login"); ?>>Login/Signup</a></button>                

                <button class="bg-grey-light hover:bg-grey  hover:text-red-500 text-grey-darkest font-semibold px-5 py-3 rounded focus:outline-none">
                    <svg class="w-6 h-6 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1m-6-1a1 1 0 001 1h1M5 17a2 2 0 104 0m-4 0a2 2 0 114 0m6 0a2 2 0 104 0m-4 0a2 2 0 114 0"></path></svg>
                    <span><a href=<?php echo e("/rider-signup"); ?>>Delivery</a></span>
                </button> 
                <a class="ml-10 text-sm hover:text-red-500" href="/vendor-signup">Become A Seller</a>
                <?php endif; ?>
                 
                  
            </div> 
                                
        </div>
    </nav>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery-System\resources\views/layouts/layout.blade.php ENDPATH**/ ?>