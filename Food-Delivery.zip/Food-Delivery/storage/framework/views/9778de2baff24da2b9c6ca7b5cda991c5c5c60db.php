
<?php $__env->startSection('title'); ?>
<title>Orders List | Foodzone</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>




<!-- component -->
<div class="col-span-5 md:col-span-4">
    <?php if( session('success')): ?>
    <div class="flex justify-center mt-2">
        <p class="mb-2 text-green-400 "><?php echo e(session('success')); ?></p>
    </div>
    <?php endif; ?>
    
    <div class="flex justify-end">
        <form method="GET" class="mb-2">
            <select name="status" class="p-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-blue-300">
                <option value="All" selected>All</option>
                <option value="Pending">Pending</option>
                <option value="Processing">Processing</option>
                <option value="Delivered">Delivered</option>
                <option value="Cancelled">Cancelled</option>
            </select>
            <input type="submit" name="Submit" value="Filter" class="bg-blue-400 text-white hover:bg-blue-500 px-3 py-2 cursor-pointer rounded">                
        </form>
    </div>
    <?php if(count($orders)): ?>
    <div class="table w-full p-2">
        <table class="table-auto w-full border">
            <thead class="border-b bg-white">
                <tr>
                    <th class = "text-sm font-thin border-r p-2">ID</th>
                    <th class = "text-sm font-thin border-r p-2">Status</th>
                    <th class = "text-sm font-thin border-r">Items</th>
                    <th class = "text-sm font-thin border-r">Customer Name</th>
                    <th class = "text-sm font-thin border-r">Phone</th>
                    <th class = "text-sm font-thin border-r">Address</th>
                    <th class = "text-sm font-thin border-r">Total</th>
                    <th class = "text-sm font-thin border-r">Time</th>
                    <th class = "text-sm font-thin border-r">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-gray-300 border-b text-center text-sm text-gray-600">
                    <td class = "border-gray-300 border-r p-2"><?php echo e($order->id); ?></td>
                    <td class = "border-gray-300 border-r p-2"><?php echo e($order->status); ?></td>
                    <td class = "border-gray-300 border-r p-2">
                        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($order->items[$items]['name']); ?> (<?php echo e($order->items[$items]['quantity']); ?>)</p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td class = "border-gray-300 border-r p-2"><?php echo e($order->customer_name); ?></td>
                    <td class = "border-gray-300 border-r p-2"><?php echo e($order->phone); ?></td>
                    <td class = "border-gray-300 border-r p-2"><?php echo e($order->shipping); ?></td>
                    <td class = "border-gray-300 border-r p-2"><?php echo e($order->sub_total); ?></td>
                    <td class = "border-gray-300 border-r p-2"><?php echo e($order->created_at); ?></td>
                    <td class = "border-gray-300 border-r p-2">
                        <?php if($order->status == "Pending"): ?>
                            <a href="/vendor-orders-accept/<?php echo e($order->id); ?>" class="bg-green-400 hover:bg-green-500 p-2 text-white text-xs font-thin">Accpet</a>
                        <?php endif; ?>                        
                        <a href="/vendor-orders/<?php echo e($order->id); ?>" class="bg-blue-400 hover:bg-blue-500 p-2 text-white text-xs font-thin">View</a>
                        <?php if(!str_contains($order->status, 'Delivered') && !str_contains($order->status, 'Picked') && !str_contains($order->status, 'Cancelled')): ?>
                        <a href="/vendor-orders-cancel/<?php echo e($order->id); ?>" class="bg-red-400 hover:bg-red-500 p-2 text-white text-xs font-thin">Cancel</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
    <?php else: ?>
    <p>No Orders Found</p>
    <?php endif; ?>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vendor.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/vendor/orders.blade.php ENDPATH**/ ?>