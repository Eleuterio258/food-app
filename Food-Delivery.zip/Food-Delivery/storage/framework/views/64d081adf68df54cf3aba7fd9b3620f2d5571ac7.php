
<?php $__env->startSection('content'); ?>

<?php if( session('success')): ?>
    <div class="flex justify-center mt-2">
        <p class="mb-2 text-green-400 "><?php echo e(session('success')); ?></p>
    </div>
<?php endif; ?>
<div class="flex justify-center gap-10 m-5">
    
    <?php if($rider && $user): ?>
    <div class=" ">
        <div class="mb-5">
            <?php if($rider->status == 'Active'): ?>
            <a href="/rider-deactivate" class=" hover:bg-red-500 hover:text-white text-red-400 p-2 rounded">Deactivate Account</a>
            <?php elseif($rider->status == "Deactivation Pending"): ?>
            <div>
                <span class="">You have a Deactivation request pending</span> <span><a href="/rider-activate" class="bg-red-300 text-white hover:bg-red-500 hover:text-white p-2 rounded mt-3">Cancel</a></span>
            </div>
            <?php endif; ?>
        </div>
        <div class="bg-white rounded p-4 shadow">
            <div class=" mt-2 text-center">
                <div class="mt-2 bg-white py-5 px-8  sm:w-96 mx-auto ">
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="py-5 text-left text-gray-600">
                            <label class="block font-semibold">Full Name</label>
                            <input type="text" name="full_name" value="<?php echo e($rider->full_name); ?>" class="border w-full  px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
            
                            <label class="block mt-3 font-semibold">Email</label>
                            <input type="email" name="email" value="<?php echo e($rider->email); ?>" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
    
                            <label class="block mt-3 font-semibold">Phone</label>
                            <input type="phone" name="phone" value="<?php echo e($rider->phone); ?>" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
    
                            <label class="block mt-3 font-semibold">Address</label>
                            <input type="text" name="address" value="<?php echo e($rider->address); ?>" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
    
                            <label class="block mt-3 font-semibold">City</label>
                            <input type="text" name="city" value="<?php echo e($rider->city); ?>" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">

                            <label class="block mt-3 font-semibold">NID</label>
                            <input type="text" name="nid" value="<?php echo e($rider->nid); ?>" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
    
    
                            <label class="block mt-3 font-semibold">Password</label>
                            <input type="password" name="password" value="<?php echo e($user->password); ?>" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
    
                        </div>
                        <div> 
                            <button type="submit" class="bg-red-400 w-full px-8 py-3 text-sm shadow-sm font-medium border text-white rounded-md hover:shadow-lg hover:bg-red-500 focus:outline-none">Update</button>                
                        </div>
                    </form>    
                </div>
            </div>       
    </div>
    <?php endif; ?>
</div>        




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.rider.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/rider/profile.blade.php ENDPATH**/ ?>