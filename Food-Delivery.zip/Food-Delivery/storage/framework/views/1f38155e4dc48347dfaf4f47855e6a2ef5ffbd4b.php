<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo $__env->yieldContent('title'); ?>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    
</head>

<body class="text-gray-600 bg-gray-100">
    <nav class="bg-white">        
        <div class="">
            <div class="">
                <div class="flex justify-center bg-white p-5 px-10 font-bold">                   
                    <a href="/"><span class=" text-gray-900 font-bold text-3xl">Foodzone</span></a>
                </div>
            </div>                                
        </div>
    </nav>


    <div class="grid md:grid-cols-5 gap-10 m-10">

        <div class="col-span-5 md:col-span-1 ">
            <div class="bg-gray-900 grid grid-cols-1 font-bold ">
                <div class="py-3 flex justify-center text-xl text-white">
                    <p>Admin Panel</p>
                </div>
                <div class=" mb-5 mt-5 py-3 bg-gray-800 flex justify-center hover:bg-white hover:text-gray-900 text-white">
                    <a href="/">Dashboard</a>
                </div>
                <div class=" mb-5 mt-5 py-3 bg-gray-800 flex justify-center hover:bg-white hover:text-gray-900 text-white">
                    <a href="/notifications">Notification</a>
                </div>
                <div class=" mb-5 mt-5 py-3 bg-gray-800 flex justify-center hover:bg-white hover:text-gray-900 text-white">
                    <a href="/all-orders">Orders</a>
                </div>
                <div class=" mb-5 mt-5 py-3 bg-gray-800 flex justify-center hover:bg-white hover:text-gray-900 text-white">
                    <a href="/all-users">Users</a>
                </div>
                <div class=" mb-5 mt-5 py-3 bg-gray-800 flex justify-center hover:bg-white hover:text-gray-900 text-white">
                    <a href="/all-shops">Shops</a>
                </div>
                <div class=" mb-5 mt-5 py-3 bg-gray-800 flex justify-center hover:bg-white hover:text-gray-900 text-white">
                    <a href="/all-foods">Foods</a>
                </div>
                <div class=" mb-5 mt-5 py-3 bg-gray-800 flex justify-center hover:bg-white hover:text-gray-900 text-white">
                    <a href="/all-riders">Riders</a>
                </div>
                <div class="  mb-5 mt-5 py-3 bg-gray-800 flex justify-center hover:bg-white hover:text-gray-900 text-white">
                    <a href="/logout">Logout</a>
                </div>
            </div>        
        </div>
        
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</body>
</html><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/layouts/admin/layout.blade.php ENDPATH**/ ?>