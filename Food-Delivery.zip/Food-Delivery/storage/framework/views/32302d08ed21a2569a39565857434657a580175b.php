
<?php $__env->startSection('title'); ?>
<title>Signup | Foodzone</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="flex justify-center bg-white">
    <div class="grid md:grid-cols-1 p-5 shadow-md">
        <?php if(count($errors) > 0): ?>
            <div class="">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="bg-yellow-100 border border-yellow-300 px-2 py-2 mt-1 text-yellow-500 rounded"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>    
        <div class=" mt-2 text-center">
            <span class="text-2xl font-bold text-gray-800">Signup</span>
            <div class="mt-2 bg-white py-5 px-8  sm:w-96 mx-auto ">
                <form action="" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="py-5 text-left text-gray-600">
                        <label class="block font-semibold">Full Name</label>
                        <input type="text" name="full_name" placeholder="Enter Full Name" class="border w-full  px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
        
                        <label class="block mt-3 font-semibold">Email</label>
                        <input type="email" name="email" placeholder="Email" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">

                        <label class="block mt-3 font-semibold">Phone</label>
                        <input type="phone" name="phone" placeholder="+880" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">

                        <label class="block mt-3 font-semibold">Address</label>
                        <input type="text" name="address" placeholder="Street Address" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">

                        <label class="block mt-3 font-semibold">City</label>
                        <input type="text" name="city" placeholder="Your city" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">


                        <label class="block mt-3 font-semibold">Password</label>
                        <input type="password" name="password" placeholder="Password" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">

                        <label class="block mt-3 font-semibold">Confirm Password</label>
                        <input type="password" name="password_confirmation" placeholder="Password Again" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                    </div>
                    <div> 
                        <button type="submit" class="bg-red-400 w-full px-8 py-3 text-sm shadow-sm font-medium border text-white rounded-md hover:shadow-lg hover:bg-red-500 focus:outline-none">Signup</button>                
                    </div>
                    <div class="mt-5">
                        <a class="text-red-400 hover:text-red-500" href=<?php echo e("/login"); ?>>Login</a> If you already have an account
                    </div>
                </form>    
            </div>
        </div>
    </div>
</div>

    
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/signup.blade.php ENDPATH**/ ?>