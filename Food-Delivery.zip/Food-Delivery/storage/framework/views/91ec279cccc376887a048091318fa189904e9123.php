
<?php $__env->startSection('title'); ?>
<title>Foodzone</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    

<main class="px-5 py-5 lg:px-40 lg:py-6">
<div>
    <?php if( session('success')): ?>
        <p class=" mb-2 text-green-400 "><?php echo e(session('success')); ?></p>
        <?php endif; ?>
    <div class="font-bold mt-2 mb-2 pb-2 border-b border-gray-300 flex justify-between">
        <div>
            <p>Popular Items</p>
        </div>
        <div>
            <a class="hover:text-red-500 font-normal" href="/foods">See all</a>
        </div>
    </div>
    
    <div class="flex justify-evenly">        
        <div class="grid gap-5 grid-cols-2 md:grid-cols-3 2xl:grid-cols-4">            
            <!-- Card start  -->
            <?php if($popular_foods): ?>
            <?php $__currentLoopData = $popular_foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="h-56 w-44 xl:h-80 xl:w-72">
                <div class="text-gray-400 text-xs xl:text-base box-border  border-1 p-1 bg-white rounded-b-none rounded-t-md shadow overflow-hidden relative">
                    <div class="border-b border-gray-100 ">
                        <a href="foods/<?php echo e($food->id); ?>">
                            <img src="/storage/<?php echo e($food->image); ?>" alt="image loading" class="object-cover w-full h-48 rounded ">
                            <div class="m-1 flex justify-between">
                                <div>
                                    <span class="text-gray-600 font-bold"><?php echo e($food->name); ?></span>                                        
                                </div>
                                <?php if($food->new_price != NULL): ?>
                                    <div>
                                        <span class="text-gray-400"><s><?php echo e($food->price); ?></s></span>
                                        <span class="text-green-500 "><?php echo e($food->new_price); ?> taka</span>
                                    </div>
                                <?php else: ?>
                                    <p><?php echo e($food->price); ?> taka</p>
                                <?php endif; ?>
                            </div>
                            <div class="">
                                <p><?php echo e($food->category); ?></p>
                            </div>                            
                    </div>
                    <div class="m-1 text-sm flex justify-between">
                        <div>
                            <span class="text-yellow-500"><?php echo e($food->rating); ?> </span><span class="">(<?php echo e($food->total_orders); ?>)</span>
                        </div>
                        <div>
                            <span class="text-gray-400"><?php echo e($food->time); ?> min</span>
                        </div>
                    </div>                        
                    </a>
                </div>
                <div class="w-full bg-red-400 hover:bg-red-500 rounded-t-none rounded-b-md px-4 py-2 text-center text-white cursor-pointer">
                    <a href="/add-to-cart/<?php echo e($food->id); ?>" >Add to Cart</a>
                </div> 
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <!-- Card end  -->            
        </div>        
    </div> 
            
    
    <div class="font-bold mt-2 mb-2 pb-2 border-b border-gray-300 flex justify-between">
        <div>
            <p>Newest Items</p>
        </div>
        <div>
            <a class="hover:text-red-500 font-normal" href="/foods">See all</a>
        </div>
    </div>
    <div class="flex justify-evenly">
        <div class="grid gap-5 grid-cols-2 md:grid-cols-3 2xl:grid-cols-4">
            <!-- Card start  -->
            <?php if($new_foods): ?>
            <?php $__currentLoopData = $new_foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="h-56 w-44 xl:h-80 xl:w-72 ">
                <div class="text-gray-400 text-xs xl:text-base box-border  border-1 p-1 bg-white rounded-b-none rounded-t-md shadow overflow-hidden relative">
                    <div class="border-b border-gray-100 ">
                        <a href="foods/<?php echo e($food->id); ?>">
                            <img src="/storage/<?php echo e($food->image); ?>" alt="image loading" class="object-cover w-full h-48 rounded ">
                            <div class="m-1 flex justify-between">
                                <div>
                                    <span class="text-gray-600 font-bold"><?php echo e($food->name); ?></span>                                        
                                </div>
                                <?php if($food->new_price != NULL): ?>
                                <div>
                                    <span class="text-gray-400"><s><?php echo e($food->price); ?></s></span>
                                    <span class="text-green-500 "><?php echo e($food->new_price); ?> taka</span>
                                </div>
                                <?php else: ?>
                                <p><?php echo e($food->price); ?> taka</p>
                                <?php endif; ?>
                                
                            </div>
                            <div class="">
                                <p><?php echo e($food->category); ?></p>
                            </div>                            
                    </div>
                    <div class="m-1 text-sm flex justify-between">
                        <div>
                            <span class="text-yellow-500"><?php echo e($food->rating); ?> </span><span class="">(<?php echo e($food->total_orders); ?>)</span>
                        </div>
                        <div>
                            <span class="text-gray-400"><?php echo e($food->time); ?> min</span>
                        </div>
                    </div>                        
                    </a>
                </div>
                <div class="w-full bg-red-400 hover:bg-red-500 rounded-t-none rounded-b-md px-4 py-2 text-center text-white cursor-pointer">
                    <a href="/add-to-cart/<?php echo e($food->id); ?>" >Add to Cart</a>
                </div> 
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <!-- Card end  -->                    
        </div>                
    </div> 
</main>
<?php $__env->stopSection(); ?>
    
    
    

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery-System\resources\views/index.blade.php ENDPATH**/ ?>