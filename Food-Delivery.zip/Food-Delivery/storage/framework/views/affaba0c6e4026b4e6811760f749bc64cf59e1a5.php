
<?php $__env->startSection('title'); ?>
<title>Notification | Foodzone</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="col-span-5 md:col-span-4 ">
    <div class="">
        <div>
            <?php if(count($notifications)): ?>
                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white p-2 mb-2  rounded shado text-sm">
                    <div class="flex justify-between">
                        <div>
                            <span class="text-blue-400"><?php echo e($notification->from); ?></span> <span><?php echo e($notification->message); ?></span>
                        </div>
                        <div>
                            <span><?php echo e($notification->created_at->diffForHumans()); ?></span>
                        </div>
                    </div>
                </div>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <p>No notifications available</p>    
            <?php endif; ?>
        </div>
        <div class="mt-5">
            <?php echo e($notifications->links()); ?>

        </div>
    </div>    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projectos\Programacao\Google\Flutter 2021\06-import\sus\Food-Delivery\resources\views/admin/notifications.blade.php ENDPATH**/ ?>