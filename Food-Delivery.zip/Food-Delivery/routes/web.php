<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AdminDashboardController;


use App\Http\Controllers\CartController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\LogoutController;
use App\Http\Controllers\SignupController;

use App\Http\Controllers\VendorSignupController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\VendorItemController;
use App\Http\Controllers\VendorShopController;
use App\Http\Controllers\VendorDashboardController;
use App\Http\Controllers\VendorAccountController;


use App\Http\Controllers\RiderSignupController;
use App\Http\Controllers\RiderAccountController;

use App\Http\Controllers\FoodController;
use App\Http\Controllers\ShopController;


use App\Http\Controllers\OrderController;
use App\Http\Controllers\RiderOrderController;

use App\Http\Controllers\RiderController;
use App\Http\Controllers\SearchController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Common routes
Route::get('/', [HomeController::class, 'index']);

Route::get('/cart', [CartController::class, 'index']);
Route::get('/add-to-cart/{id}', [CartController::class, 'cartAdd']);
Route::get('/remove-from-cart/{id}', [CartController::class, 'removeFromCart']);

Route::get('/foods', [FoodController::class, 'index']);
Route::get('/foods/{id}', [FoodController::class, 'view']);

Route::get('/shops', [ShopController::class, 'index']);
Route::get('/shops/{id}', [ShopController::class, 'view']);

Route::get('/logout', [logoutController::class, 'logout']);

// Route::get('/search/', [AdminController::class, 'search']);
// Route::get('/search/', [AdminController::class, 'search']);
// Route::get('/search/', [AdminController::class, 'search']);

Route::middleware(['login'])->group(function () {

    
    Route::get('/login', [LoginController::class, 'index']);
    Route::post('/login', [LoginController::class, 'login']);
    Route::get('/signup', [SignupController::class , 'index']);
    Route::post('/signup', [SignupController::class , 'signup']);

    Route::get('/vendor-signup', [VendorSignupController::class, 'index']);
    Route::post('/vendor-signup', [VendorSignupController::class, 'signup']);

    Route::get('/rider-signup', [RiderSignupController::class, 'index']);
    Route::post('/rider-signup', [RiderSignupController::class, 'signup']);
});



// customer routes
Route::middleware(['customer'])->group(function () {

    Route::get('/user-orders', [OrderController::class, 'index']);
    Route::get('/user-orders/{id}', [OrderController::class, 'show']);
    Route::get('/order-cancel/{id}', [OrderController::class, 'cancel']);
    Route::get('/checkout', [CheckoutController::class, 'index']);
    Route::post('/checkout', [CheckoutController::class, 'placeOrder']);
    Route::post('/checkout', [CheckoutController::class, 'placeOrder']);
    Route::get('/user-profile', [UserController::class, 'profile']);
    Route::post('/user-profile', [UserController::class, 'update']);
});


// Admin routes
Route::middleware(['admin'])->group(function () {

    Route::get('/notifications', [NotificationController::class, 'adminIndex']);
    Route::get('/all-orders', [AdminController::class, 'orders']);
    Route::get('/order/{id}', [AdminController::class, 'order']);

    Route::get('/all-users', [AdminController::class, 'users']);
    Route::get('/block-user/{id}', [AdminController::class, 'blockUser']);
    Route::get('/unblock-user/{id}', [AdminController::class, 'unblockUser']);

    Route::get('/all-riders', [AdminController::class, 'riders']);
    Route::get('/approve-rider/{id}', [AdminController::class, 'approveRider']);
    Route::get('/block-rider/{id}', [AdminController::class, 'blockRider']);
    Route::get('/unblock-rider/{id}', [AdminController::class, 'unblockRider']);

    Route::get('/all-shops', [AdminController::class, 'shops']);
    Route::get('/all-foods', [AdminController::class, 'foods']);
    Route::get('/approve-shop/{id}', [AdminController::class, 'approveShop']);
    Route::get('/block-shop/{id}', [AdminController::class, 'blockShop']);
    Route::get('/unblock-shop/{id}', [AdminController::class, 'unblockShop']);
});



// Rider routes
Route::middleware(['rider'])->group(function () {

    Route::get('/rider-profile', [RiderController::class, 'profile']);
    Route::post('/rider-profile', [RiderController::class, 'update']);

    Route::get('/rider-history', [RiderOrderController::class, 'orderHistory']);

    Route::get('/rider-orders', [RiderOrderController::class, 'index']);
    Route::post('/rider-order/{id}', [RiderOrderController::class, 'deliver']);
    Route::get('/rider-order/{id}', [RiderOrderController::class, 'order']);

    Route::get('/rider-accept-order/{id}', [RiderOrderController::class, 'riderAccept']);

    Route::get('/rider-activate', [RiderAccountController::class, 'activateRider']);
    Route::get('/rider-deactivate', [RiderAccountController::class, 'deactivateRider']);
    
});



// Vendor routes
Route::middleware(['vendor'])->group(function () {

    Route::get('/vendor-notifications', [NotificationController::class, 'vendorIndex']);
    Route::get('/vendor-deactivate', [VendorAccountController::class, 'deactivateVendor']);
    Route::get('/vendor-activate', [VendorAccountController::class, 'activateVendor']);
    Route::get('/vendor-orders', [OrderController::class, 'vendorOrders']);
    Route::get('/vendor-orders/{id}', [OrderController::class, 'vendorOrder']);
    Route::get('/vendor-orders-accept/{id}', [OrderController::class, 'vendorAccept']);
    Route::get('/vendor-orders-cancel/{id}', [OrderController::class, 'vendorCancel']);
    Route::get('/vendor-shop', [VendorShopController::class, 'index']);
    Route::post('/vendor-shop', [VendorShopController::class, 'update']);

    Route::get('/vendor-foods', [VendorItemController::class, 'index']);
    Route::post('/vendor-foods', [VendorItemController::class, 'create']);

    Route::get('/item-details/{id}', [VendorItemController::class, 'view']);
    Route::post('/item-details/{id}', [VendorItemController::class, 'update']);

    Route::get('/item-status/{id}/{status}', [VendorItemController::class, 'changeStatus']);
    
});




// Route::get('/clear', [logoutController::class, 'clear']);
// Route::get('/check', [logoutController::class, 'check']);
// Route::get('/test', [VendorDashboardController::class, 'index']);
