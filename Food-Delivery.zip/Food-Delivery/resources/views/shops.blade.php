@extends('layouts.layout')
@section('title')
<title>Shops | Foodzone</title>
@endsection
@section('content')

<main class="px-40 py-6">
    <div>
        <h4 class="font-bold mt-2 pb-2 border-b border-gray-300">All Shops</h4>
        <div class="mt-8 grid md:grid-cols-4 gap-10">
            @if($shops)
            @foreach($shops as $shop)
            <!--card-->
            <div class="bg-white rounded-md overflow-hidden shadow-md">
                <a href="/shops/{{ $shop->id}}">
                    @if ($shop->image)
                    <img src="storage/{{ $shop->image}}" alt="image loading" class="w-full h-32 sm:h-48 object-cover">
                    @else
                    <div class="w-full h-32 sm:h-48 p-5" >
                        <p class="text-2xl font-bold text-gray-300">No Image</p>
                    </div>
                    @endif
                    <div class="m-4">
                        <span class="font-bold">{{ $shop->shop_name}}</span>
                        <span class="text-sm">({{ $shop->rating }}/5)</span>
                        <span class="block text-gray-500 text-sm">{{ $shop->address}}</span>
                    </div> 
                </a>                    
            </div>
            @endforeach
            @endif
            {{-- card end --}}
        </div>
        <div class="mt-5">
            {{ $shops->links() }}
        </div>
        
    </div>
</main>
@endsection