@extends('layouts.layout')
@section('content')




<div class="grid md:grid-cols-5 gap-10 m-10">
    <div class="col-span-5 md:col-span-1">
        <div class="bg-white grid grid-cols-3 font-bold shadow">
            <div class="md:col-span-4 mb-5 mt-5 py-2 flex justify-center hover:bg-red-400 hover:text-white">
                <a href="/user-profile">Profile</a>
            </div>
            <div class="md:col-span-4 mb-5 mt-5 py-2 flex justify-center bg-red-400 text-white">
                <a href="/user-orders">Orders</a>
            </div>
            <div class="md:col-span-4  mb-5 mt-5 py-2 flex justify-center hover:bg-red-400 hover:text-white">
                <a href="/logout">Logout</a>
            </div>
        </div>        
    </div>
    <div class="col-span-5 md:col-span-4 grid gap-5 ">
        @if( session('success'))
        <p class=" mb-2 text-green-400 ">{{ session('success') }}</p>
        @endif
        @if('orders')
        @foreach($orders as $order)

            <div class="bg-white rounded p-4 shadow">
                <a href="/user-orders/{{ $order->id }}">
                    <div class="">
                        <div class="flex justify-between border-dashed border-b border-gray-300 text-md font-bold text-gray-600">
                            <?php
                                $date = $order->created_at;
                                $new_date = explode(" ", $date);                            
                            ?>
                            <div class="w-1/3 text-left">
                                <p>Order Id #{{ $order->id }}</p>
                            </div>
                            <div class="w-1/3 text-center">
                                <p class="text-green-400">{{ ucFirst($order->status) }}</p>
                            </div>
                            <div class="w-1/3 text-right">
                                <p>Date: {{ $new_date[0] }}</p>
                            </div>
                            
                            
                            
                            
                            {{-- <p class="text-yellow-400">{{ $order->shop_name }}</p> --}}
                            {{--  --}}
                        </div>
                        
                        <div class="flex justify-between ">
                            <div class="w-1/3 text-left">
                                <p class="text-yellow-400">{{ $order->shop_name }}</p>
                            </div>
                            <div class="w-1/3 text-center">
                                <p >{{ $order->sub_total }} taka</p>
                            </div>
                            <div class="w-1/3 text-right">
                                <p class="text-red-400">Payment-{{ $order->payment_status }}</p>
                            </div>
                            
                            
                            
                            {{-- @foreach($order->items as $items => $item)
                                <p>{{ $order->items[$items]['name'] }}</p>  
                                <p>{{ $order->items[$items]['quantity'] }} </p>                         
                                <p>{{ $order->items[$items]['price'] }} </p>                         
                            @endforeach --}}
                        </div>                    
                    </div>
                </a>
            </div>
        @endforeach
        @endif       
        <div class="mt-5">
            {{ $orders->links() }}
        </div>
    </div>
    
</div>


@endsection