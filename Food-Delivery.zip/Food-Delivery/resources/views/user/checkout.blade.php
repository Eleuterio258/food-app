@extends('layouts.layout')
@section('content')
    
<div class=" mx-auto md:w-2/3 lg:w-1/2">
    @if(count($errors) > 0)
            <div class="">
                <ul>
                    @foreach($errors->all() as $error)
                    <li class="bg-yellow-100 border border-yellow-300 px-2 py-2 mt-1 text-yellow-500 rounded">{{$error}}</li>
                    @endforeach
                </ul>
            </div>
        @endif
    <form action="" method="POST">
        @csrf
        @if($user)
        <div class="bg-white mt-4  py-5 px-8 shadow rounded">
            <p class="text-xl text-center font-bold m-2">Customer Information</p>
            <div class="py-5 text-left text-gray-600">
                <label class="block font-semibold" for="customer_name">Full Name</label>
                <input type="text" name="customer_name" value="{{ $user->full_name }}" class="border px-3 py-2 mb-2 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">

                <label class="block font-semibold" for="">Phone</label>
                <input type="phone" name="customer_phone" value="{{ $user->phone }}"  class="border px-3 py-2 mb-2 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">

                <label class="block font-semibold" for="">City</label>
                <input type="text" name="customer_city" value="{{ $user->city }}"  class="border px-3 py-2 mb-2 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                <label class="block font-semibold" for="">Delivery Address</label>
                <input type="text" name="customer_address" value="{{ $user->address }}"  class="border w-full px-3 py-2 mb-2 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                
                
                
            </div>
        </div>
        @endif
    
        @csrf
        
        <div class="bg-white mt-4 py-5 px-8 shadow rounded text-sm">
            <p class="text-xl text-center font-bold m-2">Order Information</p>
            {{ $price = null }}
            {{ $total = null }}
            {{ $subtotal = null }}
            {{ $quantity = null }}
            @foreach(session('cart') as  $shops=>$shop)
            <p class="text-md font-bold">Items For {{ $shops }} </p>
            <table class="rounded-t-lg m-5 w-full mx-auto bg-gray-200 text-gray-800 border-separate ">
                
            <tr class="text-left border-b-2 border-gray-300">
                <th class="px-4 py-3 w-2/3">Items</th>
                <th class="px-4 py-3">Qty</th>
                <th class="px-4 py-3">Price</th>
            </tr>
            
            
            
                @foreach($shop as $food => $details)
            <tr class="bg-gray-100 border-b border-gray-200 ">
                <td class="px-4 py-3 break-words"><input class="w-full bg-gray-100 focus:outline-none" readonly="readonly" type="text" name="product_name" value="{{$details['name']}}" ></td>
                <td class="px-4 py-3"><input class="w-full bg-gray-100 focus:outline-none" readonly="readonly" type="number" name="quantity" value="{{$details['quantity']}}" ></td>
                <td class="px-4 py-3"><input class="w-full bg-gray-100 focus:outline-none" readonly="readonly" type="number" name="price" value="{{ $price = $details['quantity'] * $details['price']}}" ></td>
            </tr> 
            <?php
              $total += $details['price']* $details['quantity'];
              $subtotal += $details['price']* $details['quantity'];
              $quantity += $details['quantity'];
              //$subtotal += $total;
            
            ?>
            @endforeach
            
            
            <tr class="bg-gray-100 border-b border-gray-200 font-bold">
                <td class="px-4 py-3 break-words">Total</td>
                <td class="px-4 py-3 break-words">{{ $quantity }}</td>
                <td class="px-4 py-3 break-words"><input class="w-full font-bold bg-gray-100 focus:outline-none" readonly="readonly" type="number" name="total" value="{{$total}}" ></td>
            </tr>
            <!-- each row -->
            <?php
                $quantity = 0;
                $total=0;
            ?>
            </table>
            @endforeach
            <input class="font-bold text-lg bg-white" type="hidden" name="subtotal" value="{{$subtotal}}" >
            <p class="font-bold text-lg">Subtotal-{{ $subtotal }} taka</p>

        </div> 
        <div class="mt-4 mb-4 flex justify-center lg:justify-end">
            <div>
                <input type="submit" name="submit" value="Place Order" class="text-white bg-red-400 hover:bg-red-500 px-4 py-2 rounded cursor-pointer">
            </div>
            
        </div> 

    </form>         
    
    
    
</div>
    



@endsection