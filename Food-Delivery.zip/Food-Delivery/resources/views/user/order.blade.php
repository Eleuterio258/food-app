@extends('layouts.layout')
@section('content')
@if($order)
@if( session('success'))
<div class="flex justify-center mt-2">
    <p class="mb-2 text-green-400 ">{{ session('success') }}</p>
</div>
    
@endif
<div class="flex justify-center mt-2">
    <div>
        <a href="/user-orders" class="text-blue-400 hover:bg-blue-500 hover:text-white px-3 py-2 rounded">back to all orders</a><br>
    </div>    
</div>
@if (str_contains($order->status, 'Picked') && $order->code != "") 
<div class="flex justify-center mt-2">
    <div class="text-center">
        <span class="text-2xl">Your Delivery Code is: </span><span class="text-2xl text-red-500">{{ $order->code }}</span>
        <p class="text-sm ">Don't share this code before you get the delivery</p> 
    </div>    
</div>

@endif
<div class="grid grid-cols-5">
    
    <div class="col-span-5 lg:col-start-2 lg:col-span-3 flex justify-center mt-2">
        <div class="flex justify-center w-full lg:w-4/5 text-xs lg:text-base min-h-screen">
            <div class="bg-white shadow p-10 w-full md:w-4/5 h-full">
                @if($order->status == "Pending")
                <div class="flex justify-between">
                    <h3 class="text-2xl font-bold">Order Information</h3>
                    <a href="/order-cancel/{{$order->id}}" class="bg-red-400 hover:bg-red-500 text-white text-xs px-3 py-2">Cancel Order</a>
                </div>
                @else
                <h3 class="text-2xl font-bold">Order Information</h3>
                @endif
                
                <div class="">
                    
                    <div class="flex justify-between mb-5">
                        <div>
                            <p>Order Number #{{ $order->id }}</p>
                            <p>Order Status: {{ ucFirst($order->status) }}</p>
                        </div>
                        <div>
                            <p>Date: {{ $order->created_at }}</p>
                        </div>
                                                
                        
                    </div>
                    <div class="flex justify-between mb-5">
                        <div  class="">
                            <p class="font-bold">Bill To</p>
                            <span class="font-bold">Name:</span> <span>{{ $order->customer_name }}</span> <br>
                            <span class="font-bold">Address:</span> <span>{{ $order->shipping }}</span><br>
                            <span class="font-bold">City:</span> <span>{{ $order->city }}</span><br>
                            <span class="font-bold">Phone:</span> <span>{{ $order->phone }}</span><br>
                        </div>
                        <div class="">
                            <p class="font-bold">Bill From</p>
                            <p>{{ $order->shop_name }}</p>
                        </div>
                    </div>
                    <div class="mb-5">
                        <p class="font-bold mb-2">Description</p>
                        <table class="table-fixed w-full text-left ">
                            <tr class="border">
                                <th class="w-1/2 p-1">Item</th>
                                <th>Quantity</th>
                                <th>Price</th>
                            </tr>
                            
                            @foreach($order->items as $items => $item)
                            <tr class="border">
                                <td class="p-1">{{ $order->items[$items]['name'] }}</td>  
                                <td class="p-1">{{ $order->items[$items]['quantity'] }}</td>                         
                                <td class="p-1">{{ $order->items[$items]['price'] }} </td>  
                            </tr>                       
                            @endforeach                            
                        </table>
                    </div>
                    <div class="mt-5">
                        <p class="text-xl lg:text-2xl">Total: {{ $order->sub_total}} taka</p>
                        <span >Payment Status: </span> <span class="text-red-400">{{ $order->payment_status }}</span> <br>
                        
                    </div>
                </div> 
            
        </div>
    </div>

       
</div>
@else
    <div class="text-center mt-10 bg-red-100 p-2">
        <p class="text-3xl bg-white p-5">No Orders Found</p>
    </div>        
@endif 
    


@endsection
