@extends('layouts.layout')
@section('content')


<div class="grid md:grid-cols-5 gap-10 m-10">
    <div class="col-span-5 md:col-span-1">
        <div class="bg-white grid grid-cols-3 font-bold shadow">
            <div class="md:col-span-4 mb-5 mt-5 py-2 flex justify-center bg-red-400 text-white">
                <a href="/user-profile">Profile</a>
            </div>
            <div class="md:col-span-4 mb-5 mt-5 py-2 flex justify-center hover:bg-red-400 hover:text-white">
                <a href="/user-orders">Orders</a>
            </div>
            <div class="md:col-span-4  mb-5 mt-5 py-2 flex justify-center hover:bg-red-400 hover:text-white">
                <a href="/logout">Logout</a>
            </div>
        </div>        
    </div>
    <div class="col-span-5 md:col-span-4 grid gap-5 ">
        @if( session('success'))
            <p class="mb-2 text-green-400 ">{{ session('success') }}</p>
        @endif
        @if(count($errors) > 0)
            <div class="">
                <ul>
                    @foreach($errors->all() as $error)
                    <li class="bg-yellow-100 border border-yellow-300 px-2 py-2 mt-1 text-yellow-500 rounded">{{$error}}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @if('customer' && 'user')
        <div class="bg-white rounded p-4 shadow">
            <div class=" mt-2 text-center">
                <div class="mt-2 bg-white py-5 px-8  sm:w-96 mx-auto">
                    <form method="POST" >
                        @csrf
                        <div class="py-5 text-left text-gray-600">
                            <label class="block font-semibold">Full Name</label>
                            <input type="text" name="full_name" value="{{ $customer->full_name}}" class="border w-full  px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
            
                            <label class="block mt-3 font-semibold">Email</label>
                            <input type="email" name="email" value="{{ $customer->email }}" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
    
                            <label class="block mt-3 font-semibold">Phone</label>
                            <input type="text" name="phone" value="{{ $customer->phone }}" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
    
                            <label class="block mt-3 font-semibold">Address</label>
                            <input type="text" name="address" value="{{ $customer->address }}" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
    
                            <label class="block mt-3 font-semibold">City</label>
                            <input type="text" name="city" value="{{ $customer->city }}" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
    
    
                            <label class="block mt-3 font-semibold">Password</label>
                            <input type="text" name="password"  value="{{ $user->password }}" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md ">
                        </div>
                        <div> 
                            <button type="submit" class="bg-red-400 w-full px-8 py-3 text-sm shadow-sm font-medium border text-white rounded-md hover:shadow-lg hover:bg-red-500 focus:outline-none">Update</button>                
                        </div>
                    </form>    
                </div>
            </div>
            @endif       
    </div>
</div>        




@endsection