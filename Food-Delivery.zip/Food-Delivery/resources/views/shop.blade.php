@extends('layouts.layout')
@section('title')
<title>Shops Details | Foodzone</title>
@endsection
@section('content')

@if($shop)
<div class="mt-2 flex justify-center">
    <div class="bg-white p-1 rounded shadow">
        <img class="w-12 h-12 md:h-24 md:w-24" src="/storage/{{$shop->image}}" alt="Image"/>
    </div>    
</div>
<div class="flex justify-center">
    <div class="mt-1">
        <p class="text-xl md:text-2xl font-bold text-gray-600">{{ $shop->shop_name }}</p>
        <p class="text-xs md:text-md text-gray-600 mt-2">{{ $shop->address }}</p>
        <p class="text-xs md:text-md text-gray-600 mt-2">{{ $shop->phone}}</p>
    </div>
</div>
@endif

<main class="px-40 py-6 ">
    <div class="flex justify-center">
        @if( session('success'))
            <p class=" mb-2 text-green-400 ">{{ session('success') }}</p>
        @endif
    </div>

    <div class="flex justify-evenly">
        <div class="grid gap-5 grid-cols-2 md:grid-cols-3 2xl:grid-cols-4">
            @if(!$foods->isEmpty())
                @foreach($foods as $food)
                <div class="h-56 w-44 xl:h-80 xl:w-72">
                    <div class="text-gray-400 text-xs xl:text-base box-border  border-1 p-1 bg-white rounded-b-none rounded-t-md shadow overflow-hidden relative">
                        <div class="border-b border-gray-100 ">
                            <a href="">
                                <img src="/storage/{{ $food->image}}" alt="image loading" class="object-cover w-full h-48 rounded ">
                                <div class="m-1 flex justify-between">
                                    <div>
                                        <span class="text-gray-600 font-bold">{{ $food->name}}</span>                                        
                                    </div>
                                    @if($food->new_price != NULL)
                                        <div>
                                            <span class="text-gray-400"><s>{{ $food->price }}</s></span>
                                            <span class="text-green-500 ">{{$food->new_price}} taka</span>
                                        </div>
                                    @else
                                        <p>{{ $food->price }} taka</p>
                                    @endif
                                </div>
                                <div class="">
                                    <span class="">Chicken,</span>
                                    <span class="">Mashrooms</span>
                                </div>                            
                        </div>
                        <div class="m-1 text-sm flex justify-between">
                            <div>
                                <span class="text-yellow-500">{{ $food->rating}} </span><span class="">({{ $food->total_orders }})</span>
                            </div>
                            <div>
                                <span class="text-gray-400">{{ $food->time }} min</span>
                            </div>
                        </div>                        
                        </a>
                    </div>
                    <div class="w-full bg-red-400 hover:bg-red-500 rounded-t-none rounded-b-md px-4 py-2 text-center text-white cursor-pointer">
                        <a href="/add-to-cart/{{ $food->id }}" >Add to Cart</a>
                    </div> 
                </div>
                @endforeach              
            <!--card-->
        </div>

        @else
        <P class="text-2xl font-bold text-gray-400">No Items Available</P>
        @endif 
    </div>
    
</main>


@endsection