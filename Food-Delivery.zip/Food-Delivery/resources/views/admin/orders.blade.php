@extends('layouts.admin.layout')
@section('title')
<title>Orders | Foodzone</title>
@endsection
@section('content')

<div class="col-span-5 md:col-span-4 grid gap-5 ">
    <div>
        @if(count($orders))
            @foreach($orders as $order)        
                <div class="bg-white rounded p-4 shadow mb-4">
                    <a href="/order/{{ $order->id }}">
                        
                        <div class=" p-2">
                            <div class="flex justify-between border-dashed text-xs text-gray-600">
                                <p>Order ID #{{ $order->id }}</p>                       
                                <p>Placed on-{{ $order->created_at }}</p>                       
                            </div>
                            <div class="flex justify-between border-dashed border-b border-gray-300 text-lg font-bold text-gray-600">
                                <p>{{ $order->shop_name }}</p>
                                <p class="text-sm font-normal">{{ $order->status }}</p>
                                
                            </div>                    
                            <div class="flex justify-between">
                                <p>{{ $order->shipping }}</p>
                                <p>{{ $order->sub_total }} ({{ $order->payment_status}})</p>
                            </div>                                                        
                        </div>
                    </a>            
                </div>            
            @endforeach
        @endif
        <div class="mt-5">
            {{ $orders->links() }}
        </div> 
        
    </div>
       
    
</div>



@endsection