@extends('layouts.admin.layout')
@section('title')
<title>Notification | Foodzone</title>
@endsection
@section('content')

<div class="col-span-5 md:col-span-4 ">
    <div class="">
        <div>
            @if(count($notifications))
                @foreach($notifications as $notification)
                <div class="bg-white p-2 mb-2  rounded shado text-sm">
                    <div class="flex justify-between">
                        <div>
                            <span class="text-blue-400">{{ $notification->from }}</span> <span>{{ $notification->message }}</span>
                        </div>
                        <div>
                            <span>{{ $notification->created_at->diffForHumans() }}</span>
                        </div>
                    </div>
                </div>
                
                @endforeach
            @else
            <p>No notifications available</p>    
            @endif
        </div>
        <div class="mt-5">
            {{ $notifications->links() }}
        </div>
    </div>    
</div>

@endsection