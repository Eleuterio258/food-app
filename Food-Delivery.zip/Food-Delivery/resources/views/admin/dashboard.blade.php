@extends('layouts.admin.layout')
@section('title')
<title>Admin Dashboard | Foodzone</title>
@endsection
@section('content')




<div class="col-span-5 md:col-span-4 grid gap-5 bg-blue-100 p-5 shadow">
    @if($notifications != 0)

    <div class="bg-white text-lg">
        <div class="m-5">
            <span class="text-blue-400">You have {{ $notifications }} new notifications</span>
            <span ><a href="/notifications" class="text-blue-400 hover:bg-blue-500 hover:text-white px-3 py-2 rounded-lg cursor-pointer">Go >></a></span>
        </div>
        
    </div>
    
    @endif

    <div class="grid grid cols-1 md:grid-cols-3 gap-10">
        <a href="" class="bg-white p-5 hover:shadow-lg">
            <div class="text-center ">
                <p class="font-bold text-5xl mb-5 mt-5">{{ $customers }}</p>
                <p class="">Total Customers</p>
            </div>
        </a>
        <a href="" class="bg-white p-5 hover:shadow-lg">
            <div class="text-center">
                <p class="font-bold text-5xl mb-5 mt-5" >{{ $vendors }}</p>
                <p>Total Shops</p>
            </div>
        </a>
        <a href="" class="bg-white p-5 hover:shadow-lg">
            <div class="text-center">
                <p class="font-bold text-5xl mb-5 mt-5" >{{ $riders }}</p>
                <p>Total Riders</p>
            </div>
        </a>
        <a href="" class="bg-white p-5 hover:shadow-lg">
            <div class="text-center">
                <p class="font-bold text-5xl mb-5 mt-5" >{{ $blockedCustomers }}</p>
                <p>Blocked Customers</p>
            </div>
        </a>
        <a href="" class="bg-white p-5 hover:shadow-lg">
            <div class="text-center">
                <p class="font-bold text-5xl mb-5 mt-5" >{{ $blockedVendors }}</p>
                <p>Blocked Shops</p>
            </div>
        </a>
        <a href="" class="bg-white p-5 hover:shadow-lg">
            <div class="text-center">
                <p class="font-bold text-5xl mb-5 mt-5" >{{ $blockedRiders }}</p>
                <p>Blocked Riders</p>
            </div>
        </a>
        <a href="" class="bg-white p-5 hover:shadow-lg">
            <div class="text-center">
                <p class="font-bold text-5xl mb-5 mt-5" >{{ $orders }}</p>
                <p>Total Orders</p>
            </div>
        </a>
        <a href="" class="bg-white p-5 hover:shadow-lg">
            <div class="text-center">
                <p class="font-bold text-5xl mb-5 mt-5" >{{ $cancelled }}</p>
                <p>Cancelled Orders</p>
            </div>
        </a>
        <a href="" class="bg-white p-5 hover:shadow-lg">
            <div class="text-center">
                <p class="font-bold text-5xl mb-5 mt-5" >{{ $delivered }}</p>
                <p>Total Delivered Orders</p>
            </div>
        </a>
        
        
        
        
        
    </div>
    
    
</div>



@endsection