@extends('layouts.admin.layout')
@section('title')
<title>Foods | Foodzone</title>
@endsection
@section('content')

@if(count($foods))
<div class="col-span-5 md:col-span-4 grid  p-2">
    <div class="grid grid-cols-1 md:grid-cols-5 gap-3">
        @foreach($foods as $food)

            <div class="bg-white mb-2 rounded shadow h-72 w-64 overflow-hidden">
                <div class="">
                    <img class="object-cover h-48 w-full"  src="/storage/{{ $food->image }}" alt="loading">
                </div>
                <div class="p-3 text-sm"> 
                    <div class="flex justify-between">
                        <p class="text-xs text-gray-400">Product Id: {{ $food->id }}</p>
                        <p class="text-xs text-gray-400">Vendor Id: {{ $food->vendor_id }}</p>

                    </div>
                    <div class="flex justify-between">
                        <p>{{ $food->name }}</p>
                        @if($food->new_price != NULL)
                            <div>
                                <span class="text-gray-400"><s>{{ $food->price }}</s></span>
                                <span class="text-green-500 ">{{$food->new_price}} taka</span>
                            </div>
                        @else
                            <p>{{ $food->price }} taka</p>
                        @endif
                    </div>                    
                    <p>Total {{ $food->total_orders }} orders</p>
                    @if($food->status == "active")
                    <span>Product Status: </span><span class="font-bold text-green-400">{{ $food->status }}</span>
                    @elseif($food->status == "deactivated")
                    <span>Product Status: </span><span class="font-bold text-red-400">{{ $food->status }}</span>
                    @endif
                </div>
                
            </div>
        
        @endforeach
    </div>
    <div class="mt-5">
        {{ $foods->links() }}
    </div>
</div>

@endif

@endsection