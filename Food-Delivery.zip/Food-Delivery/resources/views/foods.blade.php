@extends('layouts.layout')
@section('title')
<title>All Foods | Foodzone</title>
@endsection

@section('content')
    

<main class="px-5 py-5 lg:px-40 lg:py-6">
    <div>  
        <div class="flex justify-center">
            @if( session('success'))
                <p class=" mb-2 text-green-400 ">{{ session('success') }}</p>
            @endif
        </div>      
        
        <div class="flex justify-center sm:flex-wrap md:justify-evenly mb-5">
            <div>
                <form method="GET" class="mb-2">
                    <select name="sort" placeholder="ok" class="p-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-blue-300" required>
                        <option value="All" selected>All</option>
                        <option value="New">New</option>
                        <option value="Popular">Popular</option>
                        <option value="Price High-Low">Price High-Low</option>
                        <option value="Price Low-High">Price Low-High</option>
                    </select>
                    <input type="submit" name="Submit" value="Sort" class="bg-red-300 text-white hover:bg-red-500 px-3 py-2 cursor-pointer rounded">                
                </form>
            </div>
            <div class="w-2/5">
                <form method="GET">                
                    <input type="text" name="name" placeholder="Food Name" class="p-2 w-4/5 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-blue-300 rounded" required>
                    <input type="submit" name="Submit" value="Search" class="bg-red-300 text-white hover:bg-red-500 px-5 py-2 cursor-pointer rounded">
                </form>
            </div>
            
        </div>
        @if(count($foods))
        @if($result_message != '')
        <div class="flex justify-center mb-3">
            <p class="text-gray-400">{{  $result_message }}</p>
        </div>
            
        @endif
        <div class="flex justify-evenly">
            <div class="grid  grid-cols-2 md:grid-cols-3 2xl:grid-cols-4 gap-5">
                <!-- Card start  -->
                
                @foreach($foods as $food)
                <div class="h-56 w-44 xl:h-80 xl:w-72">
                    <div class="text-gray-400 text-xs xl:text-base box-border  border-1 p-1 bg-white rounded-b-none rounded-t-md shadow overflow-hidden relative">
                        <div class="border-b border-gray-100 ">
                            <a href="foods/{{$food->id}}">
                                <img src="/storage/{{ $food->image}}" alt="image loading" class="object-cover w-full h-48 rounded ">
                                <div class="m-1 flex justify-between">
                                    <div>
                                        <span class="text-gray-600 font-bold">{{ $food->name}}</span>                                        
                                    </div>
                                    @if($food->new_price != NULL)
                                    <div>
                                        <span class="text-gray-400"><s>{{ $food->price }}</s></span>
                                        <span class="text-green-500 ">{{$food->new_price}} taka</span>
                                    </div>
                                    @else
                                    <p>{{ $food->price }} taka</p>
                                    @endif
                                </div>
                                <div class="">
                                    <span class="">Chicken,</span>
                                    <span class="">Mashrooms</span>
                                </div>                            
                        </div>
                        <div class="m-1 text-sm flex justify-between">
                            <div>
                                <span class="text-yellow-500">{{ $food->rating}} </span><span class="">({{ $food->total_orders }})</span>
                            </div>
                            <div>
                                <span class="text-gray-400">{{ $food->time }} min</span>
                            </div>
                        </div>                        
                        </a>
                    </div>
                    <div class="w-full bg-red-400 hover:bg-red-500 rounded-t-none rounded-b-md px-4 py-2 text-center text-white cursor-pointer">
                        <a href="/add-to-cart/{{ $food->id }}" >Add to Cart</a>
                    </div> 
                </div>
                @endforeach
                
                <!-- Card end  -->
                
            </div>
        </div>
        @else                
        <div class="flex justify-center mt-10">
            <div class="text-center">
                <span class="text-3xl font-bold text-gray-300 ">No Foods Found</span> <br>
                <span><a href="/foods" class="text-gray-500 hover:text-blue-500">See All Foods</a></span>
                
            </div>
            
        </div>            
    @endif
        
    </div>
    
    {{-- check if pagination exits --}}
    @if($foods instanceof \Illuminate\Pagination\AbstractPaginator )
    <div class="mt-5">
        {{ $foods->links() }}
    </div>
    @endif
                
</main>
@endsection
    
    
    
