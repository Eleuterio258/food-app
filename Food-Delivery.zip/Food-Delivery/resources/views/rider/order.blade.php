@extends('layouts.rider.layout')
@section('content')

@if( session('success'))
    <div class="flex justify-center mt-2">
        <p class="mb-2 text-green-400 ">{{ session('success') }}</p>
    </div>
@endif


<div class="flex justify-center mt-2">
    <div>
        <a href="/rider-orders" class="text-blue-400 hover:bg-blue-500 hover:text-white px-3 py-2 rounded">back to all orders</a><br>
    </div>    
</div>


<div class="flex justify-center ">
    
    @if ($order)
    <div class="bg-gray-200 w-full md:w-2/3 lg:w-1/3 m-2 p-4 shadow-lg">
        <div class="bg-white p-4">
            <div class="text-xs border-dashed border-b border-gray-300 mb-1">
                <p>Order ID #{{ $order->id }}</p>                                              
            </div>
            <div class="border-dashed border-b border-gray-300 mb-1">
                <p class="font-bold">Deliver to</p>
                <p>{{ $order->customer_name }}</p>
                <p>{{ $order->phone }}</p>
                <p>{{ $order->shipping  }}</p>
                
            </div>
            <div>
                <p class="font-bold">Deliver From</p>
                <p>{{ $order->shop_name }}</p>
                <table class="w-full border-collapse table-fixed">
                    <tr class="bg-gray-100">
                        <th class="border border-gray-400 w-2/3 ">Items</th>
                        <th class="border border-gray-400 ">Qty</th>
                        <th class="border border-gray-400 ">Price</th>
                    </tr>
                    @foreach($order->items as $items => $item)
                    <tr>
                        <td class="border border-gray-400">{{ $order->items[$items]['name'] }}</td>
                        <td class="border border-gray-400">{{ $order->items[$items]['quantity'] }}</td>
                        <td class="border border-gray-400">{{ $order->items[$items]['quantity'] * $order->items[$items]['price']  }}</td>
                    </tr>
                    @endforeach
                </table>
                <p class="font-bold">Total: {{ $order->sub_total }} taka</p>
                <div class="flex justify-center mt-2">
                    @if(str_contains($order->status, 'Picked'))
                    <form method="POST">
                        @csrf
                        <input type="text" name="code" placeholder="Code" class="shadow appearance-none border border-gray-300 rounded  py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none ">
                        <input type="submit" name="submit" value="Deliver" class="bg-green-400 text-white px-3 py-2 hover:bg-green-500 mr-2 rounded cursor-pointer">
                    </form>

                    @elseif($order->status == 'Processing')                    
                    <a class="bg-green-400 text-white px-3 py-2 hover:bg-green-500 mr-2 rounded" href="/rider-accept-order/{{ $order->id }}">Accept</a>

                    @elseif(str_contains($order->status, 'Delivered'))                    
                        <p class="text-green-500">Order Delivered</p>
                    @endif
                    
                </div>
                
            </div>
        </div>
        @if (count($errors) > 0)
            <div class = "alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li class="text-red-500 p-2">{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        @if( session('error'))
            <div class="flex justify-center mt-2">
                <p class="mb-2 text-red-400 ">{{ session('error') }}</p>
            </div>
        @endif
        
    </div>
    @else
    <p class="mt-10 text-xl">No order found!</p>
    @endif
    
</div>

@endsection