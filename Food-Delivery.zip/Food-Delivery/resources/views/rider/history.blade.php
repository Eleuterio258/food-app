@extends('layouts.rider.layout')
@section('content')




<div class="flex justify-center "> 
       
    <div class="bg-gray-200 sm:w-full md:1/2 lg:w-1/3 m-10 p-5 shadow-lg">
        
        @if(count($orders))
        <p class="text-xl">Order History</p>       
        <div >
            @foreach($orders as $order)
            <a href="/rider-order/{{ $order->id }}">
            <div class="bg-white rounded p-4 shadow mb-4">
                
                <div class=" p-2">
                    <div class="flex justify-start border-dashed text-xs text-gray-600">
                        <p>Order ID #{{ $order->id }}</p>                       
                    </div>
                    <div class="flex justify-between border-dashed border-b border-gray-300 text-lg font-bold text-gray-600">
                        <p>{{ $order->shop_name }}</p>
                        <p class="text-gray-400 text-xl font-bold">Delivered</p>
                        
                    </div>                    
                    <div class="flex justify-between">
                        <p>{{ $order->shipping }}</p>
                        <p>{{ $order->sub_total }} ({{ $order->payment_status}})</p>
                    </div>                                                        
                </div>
                
            </div>
            </a>  
            @endforeach 
            
        </div>
        @else
            <p class="mt-10 font-bold text-xl">No History Available</p>
        @endif   
        
    </div>
</div>



@endsection




