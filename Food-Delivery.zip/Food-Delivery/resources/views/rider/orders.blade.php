@extends('layouts.rider.layout')
@section('content')




<div class="flex justify-center"> 
    <div class=" sm:w-full md:1/2 lg:w-1/3 m-10 p-5 shadow-lg">
        <div class="">
            <div class="flex md:justify-end">
                <div>
                    <form method="GET">                
                        <input type="text" name="address" placeholder="Location" class="p-2 focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-blue-300 rounded" required>
                        <input type="submit" name="Submit" value="Search" class="bg-blue-400 text-white hover:bg-blue-500 px-3 py-2 cursor-pointer rounded">
                    </form>
                </div>
            </div>
        </div>
        @if(count($pickedOrder))
        <p class="text-xl mb-2 mt-2">Picked Orders</p>       
        <div >
            @foreach($pickedOrder as $order)
            <a href="/rider-order/{{ $order->id }}">
            <div class="bg-white rounded p-4 shadow mb-4">
                
                <div class=" p-2">
                    <div class="flex justify-start border-dashed text-xs text-gray-600">
                        <p>Order ID #{{ $order->id }}</p>                       
                    </div>
                    <div class="flex justify-between border-dashed border-b border-gray-300 text-lg font-bold text-gray-600">
                        <p>{{ $order->shop_name }} ({{ $order->address }})</p>
                        <p class="text-base font-normal">{{ $order->status }}</p>
                        
                    </div>                    
                    <div class="flex justify-between">
                        <p>{{ $order->shipping }}</p>
                        <p>{{ $order->sub_total }} ({{ $order->payment_status}})</p>
                    </div>                                                        
                </div>
                
            </div>
            </a>  
            @endforeach 
            
        </div>
        @endif


        @if(count($newOrders))            
        <div >
            <p class="text-xl mb-2 mt-2">Available Orders</p>
            @foreach($newOrders as $order)
            <a href="/rider-order/{{ $order->id }}">
            <div class="bg-white rounded p-4 shadow mb-4">
                
                <div class=" p-2">
                    <div class="flex justify-start border-dashed text-xs text-gray-600">
                        <p>Order ID #{{ $order->id }}</p>                       
                    </div>
                    <div class="flex justify-between border-dashed border-b border-gray-300 text-lg font-bold text-gray-600">
                        <p>{{ $order->shop_name }} ({{ $order->address }})</p>
                        <p class="text-green-400 text-xl font-bold">Available</p>
                        
                    </div>                    
                    <div class="flex justify-between">
                        <p>{{ $order->shipping }}</p>
                        <p>{{ $order->sub_total }} ({{ $order->payment_status}})</p>
                    </div>                                                        
                </div>
                
            </div>
            </a>  
            @endforeach 
            
        </div>
        @else
        <div class="text-center">
            <p class="mt-2 font-bold text-xl text-gray-400">No New Orders Available</p>
        </div>            
        @endif
    </div>
</div>
    




@endsection




