@extends('layouts.layout')
@section('title')
<title>Rider Signup | Foodzone</title>
@endsection
@section('content')
<div class="flex justify-center bg-gray-100 ">
    <div class="p-10 w-full lg:w-2/4 p-5 bg-white mt-5 shadow">
        @if(count($errors) > 0)
            <div class="">
                <ul>
                    @foreach($errors->all() as $error)
                    <li class="bg-yellow-100 border border-yellow-300 px-2 py-2 mt-1 text-yellow-500 rounded">{{$error}}</li>
                    @endforeach
                </ul>
            </div>
        @endif   
        <div class=" mt-2 text-center ">
            <span class="text-2xl font-bold text-gray-800 ">Signup</span>
            <div class="mt-5 bg-white py-5 px-8 text-md bg-gray-50 shadow">
                <form action="" method="POST">
                    @csrf
                    <div class="w-full py-5 gap-4 grid grid-cols-1 md:grid-cols-2 grid-rows-4 grid-flow-col justify-items-center text-gray-600 text-left">
                        <div class="md:w-2/3">
                            <label class="block font-semibold">Full Name</label>
                            <input type="text" name="full_name" placeholder="Enter Full Name" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                        </div>
                        <div class="md:w-2/3">
                            <label class="block font-semibold">Email</label>
                            <input type="email" name="email" placeholder="Email" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                        </div>
                        <div class="md:w-2/3">
                            <label class="block  font-semibold">Phone</label>
                            <input type="phone" name="phone" placeholder="+880" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                        </div>
                        <div class="md:w-2/3">
                            <label class="block  font-semibold">NID Number</label>
                            <input type="number" name="nid" placeholder="NID Number" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                        </div>
                        <div class="md:w-2/3">
                            <label class="block  font-semibold">Address</label>
                            <input type="text" name="address" placeholder="Street Address" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                        </div>
                        <div class="md:w-2/3">
                            <label class="block  font-semibold">City</label>
                            <input type="text" name="city" placeholder="Your city" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                        </div>
                        <div class="md:w-2/3">
                            <label class="block  font-semibold">Password</label>
                            <input type="password" name="password" placeholder="Password" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                        </div>
                        <div class="md:w-2/3">
                            <label class="block  font-semibold">Confirm Password</label>
                            <input type="password" name="password_confirmation" placeholder="Password Again" class="border w-full px-3 py-3 hover:outline-none focus:outline-none focus:ring-1 focus:ring-red-400 rounded-md">
                        </div>
                    </div>
                    <div class="w-full flex justify-around">
                        <div>
                            <button type="submit" class="bg-red-400 w-full px-8 py-3 text-sm shadow-sm font-medium border text-white rounded-md hover:shadow-lg hover:bg-red-500 focus:outline-none">Signup</button> 
                        </div>                                        
                    </div>
                    
                </form>    
            </div>
            <div class="mt-5">
                <a class="text-red-400 hover:text-red-500" href={{"/login"}}>Login</a> If you already have an account
            </div>
        </div>
    </div>
</div>

    
</body>
</html>
@endsection