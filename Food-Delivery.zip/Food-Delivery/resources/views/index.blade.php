@extends('layouts.layout')
@section('title')
<title>Foodzone</title>
@endsection
@section('content')
    

<main class="px-5 py-5 lg:px-40 lg:py-6">
<div>
    @if( session('success'))
        <p class=" mb-2 text-green-400 ">{{ session('success') }}</p>
        @endif
    <div class="font-bold mt-2 mb-2 pb-2 border-b border-gray-300 flex justify-between">
        <div>
            <p>Popular Items</p>
        </div>
        <div>
            <a class="hover:text-red-500 font-normal" href="/foods">See all</a>
        </div>
    </div>
    
    <div class="flex justify-evenly">        
        <div class="grid gap-5 grid-cols-2 md:grid-cols-3 2xl:grid-cols-4">            
            <!-- Card start  -->
            @if($popular_foods)
            @foreach($popular_foods as $food)
            <div class="h-56 w-44 xl:h-80 xl:w-72">
                <div class="text-gray-400 text-xs xl:text-base box-border  border-1 p-1 bg-white rounded-b-none rounded-t-md shadow overflow-hidden relative">
                    <div class="border-b border-gray-100 ">
                        <a href="foods/{{$food->id}}">
                            <img src="/storage/{{ $food->image}}" alt="image loading" class="object-cover w-full h-48 rounded ">
                            <div class="m-1 flex justify-between">
                                <div>
                                    <span class="text-gray-600 font-bold">{{ $food->name}}</span>                                        
                                </div>
                                @if($food->new_price != NULL)
                                    <div>
                                        <span class="text-gray-400"><s>{{ $food->price }}</s></span>
                                        <span class="text-green-500 ">{{$food->new_price}} taka</span>
                                    </div>
                                @else
                                    <p>{{ $food->price }} taka</p>
                                @endif
                            </div>
                            <div class="">
                                <p>{{ $food->category }}</p>
                            </div>                            
                    </div>
                    <div class="m-1 text-sm flex justify-between">
                        <div>
                            <span class="text-yellow-500">{{ $food->rating}} </span><span class="">({{ $food->total_orders }})</span>
                        </div>
                        <div>
                            <span class="text-gray-400">{{ $food->time }} min</span>
                        </div>
                    </div>                        
                    </a>
                </div>
                <div class="w-full bg-red-400 hover:bg-red-500 rounded-t-none rounded-b-md px-4 py-2 text-center text-white cursor-pointer">
                    <a href="/add-to-cart/{{ $food->id }}" >Add to Cart</a>
                </div> 
            </div>
            @endforeach
            @endif
            <!-- Card end  -->            
        </div>        
    </div> 
            
    
    <div class="font-bold mt-2 mb-2 pb-2 border-b border-gray-300 flex justify-between">
        <div>
            <p>Newest Items</p>
        </div>
        <div>
            <a class="hover:text-red-500 font-normal" href="/foods">See all</a>
        </div>
    </div>
    <div class="flex justify-evenly">
        <div class="grid gap-5 grid-cols-2 md:grid-cols-3 2xl:grid-cols-4">
            <!-- Card start  -->
            @if($new_foods)
            @foreach($new_foods as $food)
            <div class="h-56 w-44 xl:h-80 xl:w-72 ">
                <div class="text-gray-400 text-xs xl:text-base box-border  border-1 p-1 bg-white rounded-b-none rounded-t-md shadow overflow-hidden relative">
                    <div class="border-b border-gray-100 ">
                        <a href="foods/{{$food->id}}">
                            <img src="/storage/{{ $food->image}}" alt="image loading" class="object-cover w-full h-48 rounded ">
                            <div class="m-1 flex justify-between">
                                <div>
                                    <span class="text-gray-600 font-bold">{{ $food->name}}</span>                                        
                                </div>
                                @if($food->new_price != NULL)
                                <div>
                                    <span class="text-gray-400"><s>{{ $food->price }}</s></span>
                                    <span class="text-green-500 ">{{$food->new_price}} taka</span>
                                </div>
                                @else
                                <p>{{ $food->price }} taka</p>
                                @endif
                                
                            </div>
                            <div class="">
                                <p>{{ $food->category }}</p>
                            </div>                            
                    </div>
                    <div class="m-1 text-sm flex justify-between">
                        <div>
                            <span class="text-yellow-500">{{ $food->rating}} </span><span class="">({{ $food->total_orders }})</span>
                        </div>
                        <div>
                            <span class="text-gray-400">{{ $food->time }} min</span>
                        </div>
                    </div>                        
                    </a>
                </div>
                <div class="w-full bg-red-400 hover:bg-red-500 rounded-t-none rounded-b-md px-4 py-2 text-center text-white cursor-pointer">
                    <a href="/add-to-cart/{{ $food->id }}" >Add to Cart</a>
                </div> 
            </div>
            @endforeach
            @endif
            <!-- Card end  -->                    
        </div>                
    </div> 
</main>
@endsection
    
    
    
