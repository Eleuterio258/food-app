{{-- food card --}}
<div class=" h-56 w-44 xl:h-80 xl:w-72">
    <div class="text-gray-400 text-xs xl:text-base box-border  border-1 p-1 bg-white rounded-md shadow overflow-hidden relative">
        <div class="border-b border-gray-100  ">
            <a href="">                                    
                <img src="/img/pizza2.jpg" alt="image loading" class=" h-28 w-full xl:h-44 rounded object-cover">                                   
                <div class="m-1 flex justify-between">
                    <div>
                        <span class="text-gray-600 font-bold">Pan Pizza</span>                                        
                    </div>
                    <div class="">
                        <span class="text-gray-500 ">890.00 taka</span>
                    </div>
                </div>
                <div class="flex justify-between ml-1">
                    <div>
                        <span class="">Chicken,</span>
                        <span class="">Mashrooms</span>
                    </div>
                    <div>
                        <span class="text-yellow-500">4.3 </span><span class="">(351)</span>
                    </div>
                </div>                            
        </div>
        <div class="m-1 text-sm flex justify-between">
            <div class="mt-1">
                <span class="text-gray-400 mt-2">25 min</span>
            </div>
            <div class="bg-white hover:bg-red-500 text-red-400 hover:text-white rounded-md px-3 py-1 text-center cursor-pointer">
                <a href="" >Add to Cart</a>
            </div>
        </div>                        
        </a>
    </div>
</div>


{{-- old --}}
<div class="mt-8 grid md:grid-cols-4 gap-10">
    <!--card-->
    <div class="bg-white rounded-md overflow-hidden shadow-md relative hover:shadow-xl">
        <a href="">
        <img src="img/pizza2.jpg" alt="image loading" class="w-full h-32 sm:h-48 object-cover">
        <div class="m-4 ">
            <span class="font-bold">Pizza</span>
            <span class="text-sm">(520)</span>
            <span class="block text-gray-500 text-sm">890</span>
        </div>
        <div class="bg-gray-100 text-xs font-bold rounded-full p-2 absolute top-0 ml-2 mt-2">
            <svg class="w-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>45 mins</span>
        </div>
        </a>
    </div>
    <div class="bg-white rounded-md overflow-hidden shadow-md relative">
        <a href="">
        <img src="img/pasta2.jpg" alt="image loading" class="w-full h-32 sm:h-48 object-cover">
        <div class="m-4">
            <span class="font-bold">Pasta</span>
            <span class="text-sm">(437)</span>
            <span class="block text-gray-500 text-sm">299</span>
        </div>
        <div class="bg-gray-100 text-xs font-bold rounded-full p-2 absolute top-0 ml-2 mt-2">
            <svg class="w-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>25 mins</span>
        </div>
        </a>
    </div>
    <div class="bg-white rounded-md overflow-hidden shadow-md relative">
        <a href="">
        <img src="img/burger1.jpg" alt="image loading" class="w-full h-32 sm:h-48 object-cover">
        <div class="m-4">
            <span class="font-bold">Spicy burger</span>
            <span class="text-sm">(392)</span>
            <span class="block text-gray-500 text-sm">150</span>
        </div>
        <div class="bg-gray-100 text-xs font-bold rounded-full p-2 absolute top-0 ml-2 mt-2">
            <svg class="w-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>20 mins</span>
        </div>
        </a>
    </div>
    <div class="bg-white rounded-md overflow-hidden shadow-md relative">
        <a href="">
        <img src="img/noodles1.jpg" alt="image loading" class="w-full h-32 sm:h-48 object-cover">
        <div class="m-4">
            <span class="font-bold">Chowmein</span>
            <span class="text-sm">(241)</span>
            <span class="block text-gray-500 text-sm">250</span>
        </div>
        <div class="bg-gray-100 text-xs font-bold rounded-full p-2 absolute top-0 ml-2 mt-2">
            <svg class="w-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>15 mins</span>
        </div>
        </a>
    </div>
    <div class="bg-white rounded-md overflow-hidden shadow-md relative">
        <a href="">
        <img src="img/Italian-Food.jpg" alt="image loading" class="w-full h-32 sm:h-48 object-cover">
        <div class="m-4">
            <span class="font-bold">Spaghetti</span>
            <span class="text-sm">(1)</span>
            <span class="block text-gray-500 text-sm">390</span>
        </div>
        <div class="bg-gray-100 text-xs font-bold rounded-full p-2 absolute top-0 ml-2 mt-2">
            <svg class="w-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>45 mins</span>
        </div>
        </a>
    </div>
    <div class="bg-white rounded-md overflow-hidden shadow-md relative">
        <a href="">
        <img src="img/satay-4546w.jpg" alt="image loading" class="w-full h-32 sm:h-48 object-cover">
        <div class="m-4">
            <span class="font-bold">Chicken Kebab</span>
            <span class="text-sm">(2)</span>
            <span class="block text-gray-500 text-sm">299</span>
        </div>
        <div class="bg-gray-100 text-xs font-bold rounded-full p-2 absolute top-0 ml-2 mt-2">
            <svg class="w-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>25 mins</span>
        </div>
        </a>
    </div>
    <div class="bg-white rounded-md overflow-hidden shadow-md relative">
        <a href="">
        <img src="img/pasta1.jpg" alt="image loading" class="w-full h-32 sm:h-48 object-cover">
        <div class="m-4">
            <span class="font-bold">Pasta</span>
            <span class="text-sm">(6)</span>
            <span class="block text-gray-500 text-sm">350</span>
        </div>
        <div class="bg-gray-100 text-xs font-bold rounded-full p-2 absolute top-0 ml-2 mt-2">
            <svg class="w-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>20 mins</span>
        </div>
        </a>
    </div>
    <div class="bg-white rounded-md overflow-hidden shadow-md relative">
        <a href="">
        <img src="img/delicious-italian-dishes.jpg" alt="image loading" class="w-full h-32 sm:h-48 object-cover">
        <div class="m-4">
            <span class="font-bold">Chicken curry</span>
            <span class="text-sm">(9)</span>
            <span class="block text-gray-500 text-sm">250</span>
        </div>
        <div class="bg-gray-100 text-xs font-bold rounded-full p-2 absolute top-0 ml-2 mt-2">
            <svg class="w-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>15 mins</span>
        </div>
        </a>                    
    </div>
    <div class="bg-white rounded-md overflow-hidden shadow-md relative">
        <a href="">
        <img src="img/pizza2.jpg" alt="image loading" class="w-full h-32 sm:h-48 object-cover">
        <div class="m-4">
            <span class="font-bold">Pizza</span>
            <span class="text-sm">(520)</span>
            <span class="block text-gray-500 text-sm">890</span>
        </div>
        <div class="bg-gray-100 text-xs font-bold rounded-full p-2 absolute top-0 ml-2 mt-2">
            <svg class="w-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>45 mins</span>
        </div>
        </a>
    </div>
    <div class="bg-white rounded-md overflow-hidden shadow-md relative">
        <a href="">
        <img src="img/pasta2.jpg" alt="image loading" class="w-full h-32 sm:h-48 object-cover">
        <div class="m-4">
            <span class="font-bold">Pasta</span>
            <span class="text-sm">(437)</span>
            <span class="block text-gray-500 text-sm">299</span>
        </div>
        <div class="bg-gray-100 text-xs font-bold rounded-full p-2 absolute top-0 ml-2 mt-2">
            <svg class="w-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>25 mins</span>
        </div>
        </a>
    </div>
    <div class="bg-white rounded-md overflow-hidden shadow-md relative">
        <a href="">
        <img src="img/burger1.jpg" alt="image loading" class="w-full h-32 sm:h-48 object-cover">
        <div class="m-4">
            <span class="font-bold">Spicy burger</span>
            <span class="text-sm">(392)</span>
            <span class="block text-gray-500 text-sm">150</span>
        </div>
        <div class="bg-gray-100 text-xs font-bold rounded-full p-2 absolute top-0 ml-2 mt-2">
            <svg class="w-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>20 mins</span>
        </div>
        </a>
    </div>
    <div class="bg-white rounded-md overflow-hidden shadow-md relative">
        <a href="">
        <img src="img/noodles1.jpg" alt="image loading" class="w-full h-32 sm:h-48 object-cover">
        <div class="m-4">
            <span class="font-bold">Chowmein</span>
            <span class="text-sm">(241)</span>
            <span class="block text-gray-500 text-sm">250</span>
        </div>
        <div class="bg-gray-100 text-xs font-bold rounded-full p-2 absolute top-0 ml-2 mt-2">
            <svg class="w-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>15 mins</span>
        </div>
        </a>
    </div>
    <div class="bg-white rounded-md overflow-hidden shadow-md relative">
        <a href="">
        <img src="img/Italian-Food.jpg" alt="image loading" class="w-full h-32 sm:h-48 object-cover">
        <div class="m-4">
            <span class="font-bold">Spaghetti</span>
            <span class="text-sm">(1)</span>
            <span class="block text-gray-500 text-sm">390</span>
        </div>
        <div class="bg-gray-100 text-xs font-bold rounded-full p-2 absolute top-0 ml-2 mt-2">
            <svg class="w-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>45 mins</span>
        </div>
        </a>
    </div>
    <div class="bg-white rounded-md overflow-hidden shadow-md relative">
        <a href="">
        <img src="img/satay-4546w.jpg" alt="image loading" class="w-full h-32 sm:h-48 object-cover">
        <div class="m-4">
            <span class="font-bold">Chicken Kebab</span>
            <span class="text-sm">(2)</span>
            <span class="block text-gray-500 text-sm">299</span>
        </div>
        <div class="bg-gray-100 text-xs font-bold rounded-full p-2 absolute top-0 ml-2 mt-2">
            <svg class="w-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>25 mins</span>
        </div>
        </a>
    </div>
    <div class="bg-white rounded-md overflow-hidden shadow-md relative">
        <a href="">
        <img src="img/pasta1.jpg" alt="image loading" class="w-full h-32 sm:h-48 object-cover">
        <div class="m-4">
            <span class="font-bold">Pasta</span>
            <span class="text-sm">(6)</span>
            <span class="block text-gray-500 text-sm">350</span>
        </div>
        <div class="bg-gray-100 text-xs font-bold rounded-full p-2 absolute top-0 ml-2 mt-2">
            <svg class="w-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>20 mins</span>
        </div>
        </a>
    </div>
    <div class="bg-white rounded-md overflow-hidden shadow-md relative">
        <a href="">
        <img src="img/delicious-italian-dishes.jpg" alt="image loading" class="w-full h-32 sm:h-48 object-cover">
        <div class="m-4">
            <span class="font-bold">Chicken curry</span>
            <span class="text-sm">(9)</span>
            <span class="block text-gray-500 text-sm">250</span>
        </div>
        <div class="bg-gray-100 text-xs font-bold rounded-full p-2 absolute top-0 ml-2 mt-2">
            <svg class="w-5 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>15 mins</span>
        </div>
        </a>                    
    </div>
</div>
