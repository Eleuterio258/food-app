@extends('layouts.layout')
@section('title')
<title>Food Details | Foodzone</title>
@endsection
@section('content')

<main class="px-5 py-5 lg:px-40 lg:py-6 text-gray-800">
    @if( session('success'))
        <p class=" mb-2 text-green-400 ">{{ session('success') }}</p>
    @endif
    <div class="flex justify-center">
        <div class="grid grid-cols-3 gap-5 w-2/3 bg-gray-50 p-5 ">
        @if(!empty($food))
        <div class="col-span-3 lg:col-span-2">
            <img class="w-full h-auto" src="/storage/{{ $food->image }}" alt="image loading" >
        </div>
        <div class="col-span-3 lg:col-span-1">
            <div>
                <p class="font-bold text-2xl">{{ $food->name }}</p>
            </div>
            <div>
                <p class="">{{ $food->price }} taka</p>
            </div>
            <div>
                <p class="text-yellow-500">{{ $food->rating }}</p>
            </div>
            @if($vendor)
            <div>
                <p>{{ $vendor->shop_name }}</p>
            </div>
            @endif
            
            <div>
                <p>{{ $food->time }}</p>
            </div>
            <div>
                <p>{{ $food->category }}</p>
            </div>
            <div>
                <p>{{ $food->details }}</p>
            </div>
            <div class="mt-10">
                <a href="/add-to-cart/{{ $food->id }}" class="bg-red-400 hover:bg-red-500  rounded-md px-4 py-2 text-center text-white cursor-pointer">Add to Cart</a>
            </div>
            
        </div>
        @endif
        </div>
        
        
    </div>
</main>



@endsection