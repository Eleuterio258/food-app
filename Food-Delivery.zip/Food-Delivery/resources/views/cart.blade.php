@extends('layouts.layout')
@section('title')
<title>Food Cart | Foodzone</title>
@endsection
@section('content')

<div class="grid grid-cols-6 gap-4 mt-5">
  <div class="col-span-6 lg:col-start-2 lg:col-span-3">
    @if( session('success'))
      <p class=" mb-2 text-green-400 ">{{ session('success') }}</p>
    @endif
    @if(session('cart'))

    @foreach(session('cart') as $shops=>$shop)
        <p class="text-2xl font-bold">Shop Name: {{ $shops }} </p>
        <div class="border border-gray-300 shadow mb-5">
            @foreach($shop as $food => $details)
            
            
                <div class="bg-white border-2  grid grid-cols-4 rounded ">
                    <div class="col-span-1">
                        <img class="h-24 w-32 p-1" src="/storage/{{$details['image']}}" alt="image">
                    </div>
                    <div class="flex flex-wrap content-center">
                        <p class="">{{$details['name']}}</p>                 
                    </div>
                    <div class="flex flex-wrap content-center">
                        <p class="">{{$details['price']}} taka</p>                 
                    </div>
                        <div class="flex flex-wrap content-center">
                        <div class="flex justify-between gap-x-2">
                          <!-- <div>
                            <button class="hover:text-red-500 focus:outline-none" onclick="decrement()">
                              <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                            </button>
                          </div> -->
                          <div>
                            <span id="quantity">Quantity: {{ $details['quantity']}}</span>
                          </div>
                          <!-- <div>
                            <button class="hover:text-green-500 focus:outline-none" onclick="increment()">
                              <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                            </button>
                          </div> -->
                          <div class="ml-2 ">
                            <a href="/remove-from-cart/{{$details['id']}}"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></a>  
                            </div>
                          
                            <!-- <div class="custom-number-input h-10 w-32">
                            <div class="flex flex-row h-10 w-full rounded-lg relative bg-transparent mt-1">
                                <button data-action="decrement" class=" bg-gray-300 text-gray-600 hover:text-gray-700 hover:bg-gray-400 h-full w-20 rounded-l cursor-pointer outline-none">
                                <span class="m-auto text-2xl font-thin">−</span>
                                </button>
                                <input type="number" class="outline-none focus:outline-none text-center w-full bg-gray-300 font-semibold text-md hover:text-black focus:text-black  md:text-basecursor-default flex items-center text-gray-700  outline-none" name="custom-input-number" value="{{$details['quantity']}}"></input>
                                <button data-action="increment" class="bg-gray-300 text-gray-600 hover:text-gray-700 hover:bg-gray-400 h-full w-20 rounded-r cursor-pointer">
                                <span class="m-auto text-2xl font-thin">+</span>
                                </button>
                            </div>
                            </div> -->
                            <!-- <div class="mt-2 ml-2 ">
                            <a href="/remove-from-cart/{{$details['id']}}"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></a>  
                            </div> -->
                        </div>                    
                        </div> 
                    
                    </div>
                
                
            @endforeach
        </div>
        
        
    @endforeach
  </div> 
    
    
    <div class="col-span-6 lg:col-start-5 lg:col-span-1 ">
        <div class="bg-gray-200 text-gray-800 p-5 ">
            <div class=" border-b border-gray-400" >
                <p class="font-bold mb-2">Order Summary</p>
            </div>
            <div class="flex justify-between">
                <p>Item</p>
                <p>Price</p>
            </div>
            {{ $total = null }}
            {{ $subtotal = null }}
            @foreach(session('cart') as  $shops=>$shop)
            @foreach($shop as  $food => $details)
            <div class="flex justify-between">
                <p>{{$details['name']}} ({{$details['quantity']}})</p>
                <p>{{ $total = $details['price']* $details['quantity'] }}</p>
                <?php  $subtotal += $details['price']* $details['quantity']  ?>
            </div>
            @endforeach
            @endforeach
            <div class="font-bold border-t border-gray-400 flex justify-between mt-2" >
                <p>Total</p>
                {{ $subtotal }}
            </div>
            <div class="mt-4 ">
                <a class=" w-full bg-red-400 hover:bg-red-500 text-white px-4 py-2" href="/checkout">Checkout</a>
            </div>
            
        </div >
        
    </div>
    @else
      <p>Your Cart is empty</p>
      @endif
</div>


  
  <script>

    function increment(){
      var quantity = document.getElementById('quantity').innerHTML;
      if(quantity >= 10){
        alert("You can not order more that 10 items at a time");
      }else{
        document.getElementById('quantity').innerHTML = ++quantity;
      }

      
    }

    function decrement(){
      var quantity = document.getElementById('quantity').innerHTML;
      if(quantity <= 1){
        alert("Minimum order quantiy is 1, you can remove the item if you want");
      }else{
        document.getElementById('quantity').innerHTML = --quantity;
      }

      
    }
    // function decrement(e) {
    //   const btn = e.target.parentNode.parentElement.querySelector(
    //     'button[data-action="decrement"]'
    //   );
    //   const target = btn.nextElementSibling;
    //   let value = Number(target.value);
    //   value--;
    //   target.value = value;
    // }
  
    // function increment(e) {
    //   const btn = e.target.parentNode.parentElement.querySelector(
    //     'button[data-action="decrement"]'
    //   );
    //   const target = btn.nextElementSibling;
    //   let value = Number(target.value);
    //   value++;
    //   target.value = value;
    // }
  
    // const decrementButtons = document.querySelectorAll(
    //   `button[data-action="decrement"]`
    // );
  
    // const incrementButtons = document.querySelectorAll(
    //   `button[data-action="increment"]`
    // );
  
    // decrementButtons.forEach(btn => {
    //   btn.addEventListener("click", decrement);
    // });
  
    // incrementButtons.forEach(btn => {
    //   btn.addEventListener("click", increment);
    // });
  </script>

@endsection

  
  