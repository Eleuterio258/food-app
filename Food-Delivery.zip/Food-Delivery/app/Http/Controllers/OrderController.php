<?php

namespace App\Http\Controllers;
use App\Models\Customer;
use App\Models\Vendor;
use App\Models\Rider;
use App\Models\Order;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index(){
        $email = session()->get('email');
        $user = Customer::where('email', $email)->first();
        $orders = Order::where('customer_id', $user->id)->orderBy('id', 'desc')->paginate(7);
        return view('user.orders', compact('orders'));
    }

    public function show($id){
        $order = Order::find($id);
        return view('user.order', compact('order'));
    }

    public function cancel($id){
        $order = Order::find($id)->update([
            'status' => 'Cancelled by customer'
        ]);
        return \App::make('redirect')->back()->with('success', 'Order Cancelled Successfully');
    }

    public function vendorOrders(){
        $email = session()->get('email');
        $vendor = Vendor::where('email', $email)->first();
        $shop = $vendor->shop_name;

        if(!empty($_GET['status'])){
            if($_GET['status'] == 'All'){
                $orders = Order::where('shop_name', $shop)->orderBy('id', 'desc')->get();
            }
            else{
                $orders = Order::where('shop_name', $shop)->where('status', 'LIKE', '%' . $_GET['status'] . '%')->orderBy('id', 'desc')->get();
            }
            
        }
        else{
            $orders = Order::where('shop_name', $shop)->orderBy('id', 'desc')->get();
        }

        
        return view('vendor.orders', compact('orders'));
    }

    public function vendorOrder($id){
        $email = session()->get('email');
        $vendor = Vendor::where('email', $email)->first();
        $shop = $vendor->shop_name;

        $order = Order::find($id);
        return view('vendor.order', compact('order'));
    }

    public function vendorCancel($id){
        $email = session()->get('email');
        $vendor = Vendor::where('email', $email)->first();
        $shop = $vendor->shop_name;
        $order = Order::find($id)->update([
            'status' => 'Cancelled by Vendor'
        ]);
        return \App::make('redirect')->back()->with('success', 'Order Cancelled Successfully');

    }

    public function vendorAccept($id){
        $email = session()->get('email');
        $vendor = Vendor::where('email', $email)->first();
        $shop = $vendor->shop_name;
        $order = Order::find($id)->update([
            'status' => 'Processing'
        ]);
        return \App::make('redirect')->back()->with('success', 'Order Accepted Successfully');

    }

    


}
