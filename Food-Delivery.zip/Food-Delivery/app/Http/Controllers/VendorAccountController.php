<?php

namespace App\Http\Controllers;
use App\Models\Notification;
use App\Models\Vendor;
use Illuminate\Http\Request;

class VendorAccountController extends Controller
{
    public function activateVendor(){
        $email = session()->get('email');
        $vendor = Vendor::where('email', $email)->first();

        $notification = new Notification;
        $notification->from = $vendor->shop_name;
        $notification->to = "Admin";
        $notification->message = "Has cancelled the deactivation requested of this Vendor account";
        $notification->type = "Deactivation Cancelling";
        $notification->status = "New";
        $notification->save();

        $vendor->status = "Active";
        $vendor->save();

        return \App::make('redirect')->back()->with('success', 'Deactivation Request Cancelled Successfully.');
    }

    public function deactivateVendor(){
        $email = session()->get('email');
        $vendor = Vendor::where('email', $email)->first();

        $notification = new Notification;
        $notification->from = $vendor->shop_name;
        $notification->to = "Admin";
        $notification->message = "Has requested to deactivate this account";
        $notification->type = "Deactivation";
        $notification->status = "New";
        $notification->save();

        $vendor->status = "Deactivation Pending";
        $vendor->save();

        return \App::make('redirect')->back()->with('success', 'Deactivation Request Success.');
    }
}
