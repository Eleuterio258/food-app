<?php

namespace App\Http\Controllers;
use App\Models\Order;
use App\Models\Customer;
use App\Models\Rider;
use App\Models\Vendor;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    public function orders(){
        $orders = Order::orderBy('id', 'desc')->paginate(5);
        return view('admin.orders', compact('orders'));
    }

    public function order($id){
        $order = Order::find($id);
        return view('admin.order', compact('order'));
    }

    public function users(){
        if(!empty($_GET['status'])){
            if($_GET['status'] == 'All'){
                $users = Customer::orderBy('id', 'desc')->get();
            } 
            else{
                $users = Customer::where('status', '=', $_GET['status'])->orderBy('id', 'desc')->get();
            }
           
        }
        elseif(!empty($_GET['full_name'])){
            $users = Customer::where('full_name', 'LIKE', '%' . $_GET['full_name'] . '%')->get();
        }
        else{
            $users = Customer::orderBy('id', 'desc')->get();
        }
        
        return view('admin.users', compact('users'));
    }

    public function blockUser($id){
        $customer = Customer::find($id);
        $customer->status = "Blocked";
        $customer->save();

        $user = User::where('email', '=', $customer->email)->update([
            'status' => 'Blocked'
        ]);

        return \App::make('redirect')->back()->with('success', 'User Blocked Successfully');
    }

    public function unblockUser($id){
        $customer = Customer::find($id);
        $customer->status = "Active";
        $customer->save();

        $user = User::where('email', '=', $customer->email)->update([
            'status' => 'Active'
        ]);

        return \App::make('redirect')->back()->with('success', 'User Unblocked Successfully');
    }

    public function riders(){
        if(!empty($_GET['status'])){
            if($_GET['status'] == 'All'){
                $riders = Rider::orderBy('id', 'desc')->get();
            }
            else{
                $riders = Rider::where('status', '=', $_GET['status'])->orderBy('id', 'desc')->get();
            }
            
        }
        elseif(!empty($_GET['full_name'])){
            $riders = Rider::where('full_name', 'LIKE', '%' . $_GET['full_name'] . '%')->get();
        }
        else{
            $riders = Rider::orderBy('id', 'desc')->get();
        }

        return view('admin.riders', compact('riders'));
    }

    public function approveRider($id){
        $rider = Rider::find($id);
        $rider->status = "Active";
        $rider->save();

        $user = User::where('email', '=', $rider->email)->update([
            'status' => 'Active'
        ]);

        return \App::make('redirect')->back()->with('success', 'Rider Approved Successfully');
    }

    public function blockRider($id){
        $rider = rider::find($id);
        $rider->status = "Blocked";
        $rider->save();

        $user = User::where('email', '=', $rider->email)->update([
            'status' => 'Blocked'
        ]);

        return \App::make('redirect')->back()->with('success', 'Rider Blocked Successfully');
    }

    public function unblockRider($id){
        $rider = Rider::find($id);
        $rider->status = "Active";
        $rider->save();

        $user = User::where('email', '=', $rider->email)->update([
            'status' => 'Active'
        ]);

        return \App::make('redirect')->back()->with('success', 'Rider Unblocked Successfully');
    }


    public function shops(){
        if(!empty($_GET['status'])){
            if($_GET['status'] == 'All'){
                $shops = Vendor::orderBy('id', 'desc')->get();
            }
            else{
                $shops = Vendor::where('status', '=', $_GET['status'])->orderBy('id', 'desc')->get();
            }
        }
        elseif(!empty($_GET['shop_name'])){
            $shops = Vendor::where('shop_name', 'LIKE', '%' . $_GET['shop_name'] . '%')->get();
        }
        else{
            $shops = Vendor::orderBy('id', 'desc')->get();
        }
        
        return view('admin.shops', compact('shops'));
    }

    public function foods(){
        $foods = Product::paginate(10);
        return view('admin.foods', compact('foods'));
    }

    public function approveShop($id){
        $shop= Vendor::find($id);
        $shop->status = "Active";
        $shop->save();

        $user = User::where('email', '=', $shop->email)->update([
            'status' => 'Active'
        ]);

        return \App::make('redirect')->back()->with('success', 'Shop Approved Successfully');
    }

    public function blockShop($id){
        $shop= Vendor::find($id);
        $shop->status = "Blocked";
        $shop->save();

        $user = User::where('email', '=', $shop->email)->update([
            'status' => 'Blocked'
        ]);

        return \App::make('redirect')->back()->with('success', 'Shop Blocked Successfully');
    }

    public function unblockShop($id){
        $shop= Vendor::find($id);
        $shop->status = "Active";
        $shop->save();

        $user = User::where('email', '=', $shop->email)->update([
            'status' => 'Active'
        ]);

        return \App::make('redirect')->back()->with('success', 'Shop Unblocked Successfully');
    }

    




}
