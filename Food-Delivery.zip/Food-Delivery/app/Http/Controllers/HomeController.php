<?php

namespace App\Http\Controllers;
use App\Models\Product;
use App\Models\Order;
use App\Models\Customer;
use App\Models\Rider;
use App\Models\Vendor;
use App\Models\User;
use App\Models\Notification;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index(Request $request){
        //for common
        $popular_foods = Product::orderBy('total_orders', 'desc')->orderBy('rating', 'desc')->where('status', '=', 'active')->limit(6)->get();
        $new_foods = Product::orderBy('created_at', 'desc')->where('status', '=', 'active')->limit(6)->get();               
        
        

        if ($request->session()->has('user_type')) {
            if( session('user_type') == 'admin'){
                $notifications = Notification::where('to', '=', 'Admin')->where('status', '=', 'New')->count();        

                $customers = Customer::all()->count();
                $blockedCustomers = Customer::where('status', '=',  'Blocked')->count();

                $vendors = Vendor::all()->count();
                $blockedVendors = Vendor::where('status', '=',  'Blocked')->count();

                $riders = Rider::all()->count();
                $blockedRiders = Rider::where('status', '=',  'Blocked')->count();

                $orders = Order::all()->count();
                $delivered = Order::where('status', 'LIKE',  'Delivered%')->count();
                $cancelled = Order::where('status', 'LIKE',  'Cancelled%')->count();
                return view('admin.dashboard', compact('notifications', 'customers', 'vendors', 'riders', 'orders', 'delivered', 'cancelled', 'blockedCustomers', 'blockedVendors', 'blockedRiders'));
            }
            else if( session('user_type') == 'customer'){                
                return view('index', compact('popular_foods', 'new_foods'));
            }
            else if( session('user_type') == 'vendor'){
                $email = session()->get('email');
                $vendor = Vendor::where('email', $email)->first();

                $notifications = Notification::where('to', '=', $vendor->shop_name)->where('status', '=', 'New')->count();

                $orders = Order::where('vendor_id', '=', $vendor->id)->count();
                $pending  = Order::where('vendor_id', '=', $vendor->id)->where('status', '=',  'Pending')->count();
                $processing  = Order::where('vendor_id', '=', $vendor->id)->where('status', '=',  'Processing')->count();
                $delivered = Order::where('vendor_id', '=', $vendor->id)->where('status', 'LIKE',  'Delivered%')->count();
                $cancelled = Order::where('vendor_id', '=', $vendor->id)->where('status', 'LIKE',  'Cancelled%')->count();

                $items = Product::where('vendor_id', '=', $vendor->id)->count();
                $active = Product::where('vendor_id', '=', $vendor->id)->where('status', '=',  'active')->count();
                $deactivated = Product::where('vendor_id', '=', $vendor->id)->where('status', '=',  'deactivated')->count();

                $sale = Order::where('vendor_id', $vendor->id)->where('status', 'LIKE',  'Delivered%')->sum('sub_total');
                return view('vendor.dashboard' , compact('notifications', 'orders', 'pending', 'processing', 'delivered', 'cancelled', 'items', 'active', 'deactivated', 'sale'));
            }
            else if( session('user_type') == 'rider'){
                $email = session()->get('email');
                $rider = Rider::where('email', $email)->first();

                $newOrders = Order::where('status', 'Processing')->count();
                $pickedOrders = Order::where('status', 'Picked by '. $rider->full_name)->count();
                $deliveredOrders = Order::where('status', 'Delivered by '. $rider->full_name)->count();
                $cancelledOrders = Order::where('status', 'Cancelled by '. $rider->full_name)->count();

                return view('rider.dashboard', compact('newOrders', 'pickedOrders', 'deliveredOrders', 'cancelledOrders'));
            }
        
        } else{
            
            return view('index', compact('popular_foods', 'new_foods'));
        }
    }
}
