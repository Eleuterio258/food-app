<?php

namespace App\Http\Controllers;
use App\Models\Order;
use App\Models\Customer;
use App\Models\Rider;
use App\Models\Vendor;
use App\Models\User;
use App\Models\Notification;
use Illuminate\Http\Request;

class AdminDashboardController extends Controller
{
    public function index(){
        $notifications = Notification::where('to', '=', 'Admin')->where('status', '=', 'New')->count();
        

        if(!empty($notifications)){
            $notifications = "";
        }

        $customers = Customer::all()->count();
        $blockedCustomers = Customer::where('status', '=',  'Blocked')->count();

        $vendors = Vendor::all()->count();
        $blockedVendors = Vendor::where('status', '=',  'Blocked')->count();

        $riders = Rider::all()->count();
        $blockedRiders = Rider::where('status', '=',  'Blocked')->count();

        $orders = Order::all()->count();
        $delivered = Order::where('status', 'LIKE',  'Delivered%')->count();
        $cancelled = Order::where('status', 'LIKE',  'Cancelled%')->count();
        
        
        return view('admin.dashboard', compact('notifications', 'customers', 'vendors', 'riders', 'orders', 'delivered', 'cancelled', 'blockedCustomers', 'blockedVendors', 'blockedRiders'));
    }
}
