<?php

namespace App\Http\Controllers;
use App\Models\Vendor;
use App\Models\User;
use Illuminate\Http\Request;

class DeactivateController extends Controller
{
    public function deactivateVendor($id){
        $vendor = Vendor::find($id);
        $vendor->status = "blocked";
        $vendor->save();
    }
}
