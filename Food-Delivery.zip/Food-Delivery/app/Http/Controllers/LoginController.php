<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\User;

class LoginController extends Controller
{
    public function index(){
        return view('login');
    }

    public function login(Request $request){
        $validated = $request->validate([
            'email' => 'email|required',
            'password' => 'required',
        ]);

        $email = $validated['email'];
        $password = $validated['password'];
        
        if(DB::table('users')->where('email', $email)->exists()){
            $user = DB::table('users')->where('email', '=', $email)->where('password', '=', $password)->first();
            if($user){
                if($user->status == 'Active'){
                    session([
                        'email' => $user->email,
                        'user_type' => $user->user_type
                    ]);
                    return redirect('/');
                }
                else if($user->status == 'Pending'){
                    return \App::make('redirect')->back()->with('message', 'Your account is pending approval');
                }
                else if($user->status == 'Blocked'){
                    return \App::make('redirect')->back()->with('message', 'Your account is Deactivated, please contact your administrator');
                }
                
                
            } else{
                return redirect('/login')->with('message', 'Incorrect password!');
            }
        } else{
            return redirect('/login')->with('message', 'Email address not found');
        }
    }
}
