<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

use App\Models\User;
use App\Models\Customer;

class SignupController extends Controller
{
    public function index(){
        return view('signup');
    }

    public function signup(Request $request){
        $validated = $request->validate([
            'full_name' => 'required|max:255',
            'email' => 'email|required|unique:users,email',
            'phone' => 'min:11|required|min:7|max:18|unique:users,phone',
            'address' => 'required|max:255',
            'city' => 'required||max:50',
            'password' => 'required|confirmed|min:4|max:16',
            'password_confirmation' => 'required|min:4|max:16',
        ]);
        
        $user = new User;
        $user->email = $validated['email'];
        $user->password = $validated['password'];
        $user->phone = $validated['phone'];
        $user->user_type = "customer";
        $user->status = "Active";
        $user->save();

        $customer = new Customer;
        $customer->email = $validated['email'];
        $customer->full_name = $validated['full_name'];
        $customer->phone = $validated['phone'];
        $customer->address = $validated['address'];
        $customer->city = $validated['city'];
        $customer->status = "Active";
        $customer->save();

        return redirect('/login')->with('success', 'Registration Successful');
    }
}
