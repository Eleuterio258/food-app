<?php

namespace App\Http\Controllers;
use App\Models\Rider;
use App\Models\User;
use App\Models\Notification;
use Illuminate\Http\Request;

class RiderSignupController extends Controller
{
    public function index(){
        return view('rider.signup');
    }

    public function signup(Request $request){
        $validated = $request->validate([
            'full_name' => 'required|max:255',
            'email' => 'email|required|unique:users,email',
            'phone' => 'min:7|max:18|required|unique:users,phone',
            'address' => 'required|max:255',
            'nid' => 'required|max:17|unique:riders,nid',
            'city' => 'required||max:50',
            'password' => 'required|confirmed|min:4|max:16',
            'password_confirmation' => 'required|min:4|max:16',
        ]);

        //dd($request->shop_name);
        
        $user = new User;
        $user->email = $validated['email'];
        $user->password = $validated['password'];
        $user->phone = $validated['phone'];
        $user->user_type = "rider";
        $user->status = "Pending";
        $user->save();

        $rider = new Rider;
        $rider->email = $validated['email'];
        $rider->full_name = $validated['full_name'];
        $rider->phone = $validated['phone'];
        $rider->address = $validated['address'];
        $rider->nid = $validated['nid'];
        $rider->city = $validated['city'];
        $rider->image = "no image";
        $rider->status = "Pending";
        $rider->save();

        $notification = new Notification;
        $notification->from = $validated['full_name'];;
        $notification->to = "Admin";
        $notification->message = "Has has created a new Rider account, waiting for approval";
        $notification->type = "Account Approval";
        $notification->status = "New";
        $notification->save();

        return redirect('/login')->with('success', 'Registration Successful, we will approve your registration shortly');
    }
}
