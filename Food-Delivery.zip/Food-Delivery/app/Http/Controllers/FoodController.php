<?php

namespace App\Http\Controllers;
use App\Models\Product;
use App\Models\Vendor;
use Illuminate\Http\Request;

class FoodController extends Controller
{
    public function index(){
        if(!empty($_GET['name'])){
            $foods = Product::where('name', 'LIKE', '%' . $_GET['name'] . '%')->where('status', '=', 'active')->paginate(12);
            $result_message = 'Showing results for - '. $_GET['name'] ;
        }
        elseif(!empty($_GET['sort'])){
            if($_GET['sort'] == "All"){
                $foods = Product::where('status', '=', 'active')->paginate(12);
                $result_message = 'Showing all foods';
            }
            elseif($_GET['sort'] == "New"){
                $foods = Product::where('status', '=', 'active')->orderBy('id', 'desc')->get();
                $result_message = 'Showing new foods';
            }
            elseif($_GET['sort'] == "Popular"){
                $foods = Product::where('status', '=', 'active')->orderBy('total_orders', 'desc')->get();
                $result_message = 'Showing popular foods';
            }
            elseif($_GET['sort'] == "Price High-Low"){
                $foods = Product::where('status', '=', 'active')->orderBy('price', 'desc')->get();
                $result_message = 'Showing foods starting at highest price';
            }
            elseif($_GET['sort'] == "Price Low-High"){
                $foods = Product::where('status', '=', 'active')->orderBy('price', 'asc')->get();
                $result_message = 'Showing foods starting at lowest price';
            }
        }
        else{
            $foods = Product::where('status', '=', 'active')->paginate(12);
            $result_message = '';
        }

        
        
        return view('foods', compact('foods', 'result_message'));
    }

    public function view(Request $request){
        $id = $request->id;
        $food = Product::find($id);
        $vendor_id = $food->vendor_id;
        $vendor = Vendor::find($vendor_id);
        return view('food', compact('food', 'vendor'));
    }
}
