<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function profile(){
        $email = session('email');
        $customer = Customer::where('email', $email)->first();
        $user = User::where('email', $email)->first();
        return view('user.profile', compact('customer','user'));
    }


    public function update(Request $request){
        $email = session('email');
        $customer = Customer::where('email', $email)->first();
        $user = User::where('email', $email)->first();
        $user_id = $user->id;
        $customer_id = $customer->id;

        $validated = $request->validate([
            'full_name'             =>   'max:255',
            'email'                 =>   "sometimes|required|email|unique:users,email,  $user_id" ,
            'phone'                 =>   "sometimes|required|numeric|min:11|unique:users,phone, $user_id"  ,
            'address'               =>   "max:255",
            'city'                  =>   "max:50",
            'password'              =>   "sometimes|min:4|max:16",
        ]);
        
        
        $customer =  Customer::find($customer_id)->update([
            'full_name' => $validated['full_name'],
            'email' => $validated['email'],
            'phone' => $validated['phone'],
            'address' => $validated['address'],
            'city' => $validated['city']
        ]);
        $user = User::find($user_id)->update([
            'email' => $validated['email'],
            'phone' => $validated['phone'],
            'password' => $validated['password']
        ]);
        session([
            'email' => $validated['email']
        ]);

        return \App::make('redirect')->back()->with('success', 'Profile Updated Successfully');
    }

}
