<?php

namespace App\Http\Controllers;
use App\Models\Product;
use App\Models\Vendor;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function index(Request $request){
        // if($request->session()->has('items')){
            
        // }
        // $shops = session()->get('shops');
        // dd($shops);
        return view('cart');
    }

    public function addToCart($id){
        //dd('click');
        $food = Product::find($id);
        if($food->new_price != NULL){
            $price = $food->new_price;
        } else{
            $price = $food->price;
        }

        $shop = Vendor::find($food->vendor_id);
        $shop_name = $shop->shop_name;
        //dd($shop_name);
        if(!$food){
            abort(404);
            
        } else if($food->status != 'active'){
            abort(404);
        }

        $cart = session()->get('cart');
        if(!$cart){
            $cart = [
                $id => [
                     
                    'shop' => $shop_name,
                    'food_id' => $food->id,
                    'name' => $food->name,
                    'price' => $price,
                    'quantity' => 1,
                    'image' => $food->image
                ]
            ];
            
            $shops = array($shop_name);
            session()->put('cart', $cart);
            session()->put('shops', $shops);
            return redirect()->back()->with('success', 'Product added to cart successfully!');
        }

        // if cart not empty then check if this product exist then increment quantity
        if(isset($cart[$id])){
            $cart[$id]['quantity']++;
            session()->put('cart', $cart);
            return redirect()->back()->with('success', 'Product added to cart successfully!');
        }

         // if item not exist in cart then add to cart with quantity = 1
         $cart[$id] = [
            'shop' => $shop_name,
            'name' => $food->name,
            'price' => $price,
            'quantity' => 1,
            'image' => $food->image,
            
        ];
        //$shop = $shop_name;
        $shops = session()->get('shops');
        if(in_array($shop_name, $shops)){
            session()->put('cart', $cart);
        } else{
            session()->put('cart', $cart);
            session()->push('shops', $shop_name);
        }
        
        return redirect()->back()->with('success', 'Product added to cart successfully!');
    
    }

    public function cartAdd($id){
        $food = Product::find($id);
        if($food->new_price != NULL){
            $price = $food->new_price;
        } else{
            $price = $food->price;
        }

        $shop = Vendor::find($food->vendor_id);
        $shop_name = $shop->shop_name;

        //dd($food->id);

        if(!$food){
            abort(404);
            
        } else if($food->status != 'active'){
            abort(404);
        }

        $cart = session()->get('cart');
        if(!$cart){
            $cart = [
                $shop_name => [
                    $food->name => [
                        // 'shop' => $shop_name,
                        'id' => $food->id,
                        'name' => $food->name,
                        'price' => $price,
                        'quantity' => 1,
                        'image' => $food->image
                    ]               
                ]
            ];

            session()->put('cart', $cart);
            return redirect()->back()->with('success', 'Product added to cart successfully!');
        }

        // if cart not empty then check if this product exist then increment quantity
        if(isset($cart[$shop_name])){
            if(isset($cart[$shop_name][$food->name])){
                $cart[$shop_name][$food->name]["quantity"] ++;

                session()->put('cart', $cart);
                return redirect()->back()->with('success', 'Product added to cart successfully!');
            }else{
                // create a new food item in the same shop
                $cart[$shop_name][$food->name] = [
                    // 'shop' => $shop_name,
                    'id' => $food->id,
                    'name' => $food->name,
                    'price' => $price,
                    'quantity' => 1,
                    'image' => $food->image,
                    
                ];

                session()->put('cart', $cart);
                return redirect()->back()->with('success', 'Product added to cart successfully!');
            }
        } else{
            //create a new shop
            $cart[$shop_name] = [
                $food->name => [
                    'id' => $food->id,
                    'name' => $food->name,
                    'price' => $price,
                    'quantity' => 1,
                    'image' => $food->image
                ]  
                
            ];

            session()->put('cart', $cart);
            return redirect()->back()->with('success', 'Product added to cart successfully!');
        }




        
    }

    public function removeFromCart(Request $request){
        if($id = $request->id) {
            $food = Product::find($id);
            $shop = Vendor::find($food->vendor_id);
            $shop_name = $shop->shop_name;
            $cart = session()->get('cart');

            if(isset($cart[$shop_name])){
                if(isset($cart[$shop_name][$food->name])){
                    unset($cart[$shop_name][$food->name]);
                    if(($cart[$shop_name] == null)){
                        unset($cart[$shop_name]);
                    }
                    session()->put('cart', $cart);
                    
                }
            }
        }
        return redirect()->back()->with('success', 'Product removed successfully');
    }
}
