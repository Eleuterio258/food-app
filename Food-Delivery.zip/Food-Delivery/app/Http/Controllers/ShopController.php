<?php

namespace App\Http\Controllers;
use App\Models\Vendor;
use App\Models\Product;
use Illuminate\Http\Request;

class ShopController extends Controller
{
    public function index(){
        $shops = Vendor::paginate(8);
        return view('shops', compact('shops'));
    }

    public function view(Request $request){
        $id = $request->id;
        $shop = Vendor::find($id);
        $foods = Product::where('vendor_id', $id)->get();
        return view('shop', compact('foods', 'shop'));
    }
}
