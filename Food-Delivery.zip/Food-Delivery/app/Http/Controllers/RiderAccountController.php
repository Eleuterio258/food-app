<?php

namespace App\Http\Controllers;
use App\Models\Notification;
use App\Models\Rider;
use Illuminate\Http\Request;

class RiderAccountController extends Controller
{
    public function deactivateRider(){
        $email = session()->get('email');
        $rider = Rider::where('email', $email)->first();

        $notification = new Notification;
        $notification->from = $rider->full_name;
        $notification->to = "Admin";
        $notification->message = "Has requested to deactivate this account";
        $notification->type = "Deactivation";
        $notification->status = "New";
        $notification->save();

        $rider->status = "Deactivation Pending";
        $rider->save();

        return \App::make('redirect')->back()->with('success', 'Deactivation Request Success.');
    }

    public function activateRider(){
        $email = session()->get('email');
        $rider = Rider::where('email', $email)->first();

        $notification = new Notification;
        $notification->from = $rider->full_name;
        $notification->to = "Admin";
        $notification->message = "Has cancelled the deactivation requested of this Rider account";
        $notification->type = "Deactivation Cancelling";
        $notification->status = "New";
        $notification->save();

        $rider->status = "Active";
        $rider->save();

        return \App::make('redirect')->back()->with('success', 'Deactivation Request Cancelled Successfully.');
    }
}
