<?php

namespace App\Http\Controllers;
use App\Models\Rider;
use App\Models\User;
use Illuminate\Http\Request;

class RiderController extends Controller
{
    public function show($id){

    }

    public function update(Request $request){
        $email = session('email');
        $user = User::where('email', $email)->first();
        $rider = Rider::where('email', $email)->first();
        $user_id = $user->id;
        $rider_id = $rider->id;


        $validated = $request->validate([
            'full_name'             =>   'max:255',
            'email'                 =>   "sometimes|required|email|unique:users,email,  $user_id" ,
            'phone'                 =>   "sometimes|required|numeric|min:11|unique:users,phone, $user_id"  ,
            'address'               =>   "max:255",
            'city'                  =>   "max:50",
            'nid'                   =>   "min:4|max:20",
            'password'              =>   "sometimes|min:4|max:16"
        ]);

        $rider =  Rider::find($rider_id)->update([
            'full_name' => $validated['full_name'],
            'email' => $validated['email'],
            'phone' => $validated['phone'],
            'address' => $validated['address'],
            'city' => $validated['city'],
            'nid' => $validated['nid']
        ]);
        $user = User::find($user_id)->update([
            'email' => $validated['email'],
            'phone' => $validated['phone'],
            'password' => $validated['password']
        ]);
        session([
            'email' => $validated['email']
        ]);
        return \App::make('redirect')->back()->with('success', 'Profile Updated Successfully');
    }

    public function profile(){
        $email = session('email');
        $user = User::where('email', $email)->first();
        $rider = Rider::where('email', $email)->first();

        return view('rider.profile', compact('rider', 'user'));
    }
}
