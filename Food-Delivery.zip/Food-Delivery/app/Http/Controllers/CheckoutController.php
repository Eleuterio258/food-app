<?php

namespace App\Http\Controllers;
use App\Models\Customer;
use App\Models\Order;
use App\Models\Product;
use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CheckoutController extends Controller
{
    public function index(){
        $email = session()->get('email');
        $user = Customer::where('email', $email)->first();
        $cart = session()->get('cart');
        
        if($cart){
            return view('user.checkout', compact('user'));
        }else{
            return redirect()->back();
        }
        
    }

    public function placeOrder(Request $request){
        //dd($request->all());
        $validated = $request->validate([
            'customer_name' => 'required|max:255',
            'customer_phone' => 'min:7|max:18|required',
            'customer_city' => 'min:5|required|max:50',
            'customer_address' => 'min:5|required|max:255'
        ]);

        
        //$food = $request['product_name'];
        
        //get customer id
        $email = session()->get('email');
        $customer = DB::table('customers')->where('email', "=", $email)->first();

        $cart = session()->get('cart');
        $sub_total = 0;        

        try{
            foreach ($cart as $shops => $shop) {
                $vendor = DB::table('vendors')->where('shop_name', "=", $shops)->first();
                $order = new Order;
                $order->vendor_id = $vendor->id;
                $order->shop_name = $vendor->shop_name;
                $order->address = $vendor->address;
                $order->customer_id = $customer->id;
                $order->phone = $validated['customer_phone'];
                $order->customer_name = $validated['customer_name'];
                $order->city = $validated['customer_city'];
                $order->shipping = $validated['customer_address'];
                $order->items = $shop;

                foreach($shop as $food => $details){
                    $sub_total += $cart[$shops][$food]['quantity'] * $cart[$shops][$food]['price'];
                    $product = Product::where('name', '=', $cart[$shops][$food]['name'])->first();
                    $total_orders = $product->total_orders;
                    $total_orders += $cart[$shops][$food]['quantity'];

                    DB::table('products')->where('id', $cart[$shops][$food]['id'])->update(['total_orders' => $total_orders]);    
                                       
                }
                $order->sub_total = $sub_total;
                $order->code = rand(1000, 9999);
                $order->save();
                $sub_total = 0;
                
                $notification = new Notification;
                $notification->from = $validated['customer_name'];
                $notification->to = $vendor->shop_name;
                $notification->message = "You have a new order";
                $notification->type = "Order";
                $notification->status = "New";
                $notification->save();
                        
            }
        } catch(Exception $e){
            return redirect()->back()->with('failed',"operation failed");
        }
        $request->session()->forget('cart');
        return redirect('/user-orders')->with('success', "Order Placed Successfully") ;

        
        
        

    }

}
