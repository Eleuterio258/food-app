<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use App\Models\Product;
use App\Models\Vendor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class VendorItemController extends Controller
{
    public function index(){
        //get vendor id
        $email = session('email');
        $vendor = Vendor::where('email', $email)->first();
        if($vendor){
            $id = $vendor->id;
            //get vendor's items
            $items = DB::table('products')->where('vendor_id', $id)->orderBy('id', 'desc')->paginate(10);
            //$count = $items->count();
            //dd($items);
            if(!empty($items)){
                return view('vendor.foods', compact('items'));
            } else{
                return view('vendor.foods');
            }
        } else{
            return view('vendor.foods');
        }

        
    }

    public function view(Request $request){
        $id = $request->id;
        $item = Product::find($id);
        return view('vendor.food', compact('item'));
    }

    public function update(Request $request){
        //get product id
        $id = $request->id;
        //get the product
        $product = Product::find($id);

        //validation
        $validated = $request->validate([
            'name' => 'required|max:60',
            'price' => 'required|max:4',
            'new_price' => 'max:4',
            'time' => 'required|max:4',
            //'image' => 'required|mimes:jpg,jpeg,png',
            'details' => 'required|max:255'
        ]);


        //get the image
        $img = $request->image;
        if($img){
            $img_extension = $img->getClientOriginalExtension();
            $img_name = 'item_' . time() . '.' . $img_extension;
            $path = $img->storeAs('images/items', $img_name ,  'public'); //store the image into the storage folder

            //delete existing image            
            if($product->image){
                Storage::disk('public')->delete($product->image);            
            }

            
            $item = Product::find($id)->update([
                'name' => $validated['name'],
                'price' => $validated['price'],
                'new_price' => $validated['new_price'],
                'time' => $validated['time'],
                'category' => $request['category'],
                'details' => $validated['details'],
                'image' => $path
            ]);
        } else{
            $item = Product::find($id)->update([
                'name' => $validated['name'],
                'price' => $validated['price'],
                'new_price' => $validated['new_price'],
                'time' => $validated['time'],
                'category' => $request['category'],
                'details' => $validated['details'],
            ]);
        }
        
        return \App::make('redirect')->back()->with('success', 'Updated Successfully');

    }

    public function create(Request $request){
        //validation 
        $validated = $request->validate([
            'name' => 'required|max:60',
            'price' => 'required|max:4',
            'category' => 'required',
            'time' => 'required|max:4',
            'image' => 'required|mimes:jpg,jpeg,png',
            'details' => 'required|max:255'
        ]);

        //get the image
        $img = $request->image;
        $img_extension = $img->getClientOriginalExtension();
        $img_name = 'item_' . time() . '.' . $img_extension;
        $path = $img->storeAs('images/items', $img_name ,  'public'); //store the image into the storage folder

        //get vendor id
        $email = session('email');
        $vendor = Vendor::where('email', $email)->first();
        $id = $vendor->id;        
        

        // store to database
        $product = new Product;
        $product->name = $validated['name'];
        $product->price = $validated['price'];
        $product->category = $validated['category'];
        $product->time = $validated['time'];
        $product->image = $path;
        $product->details = $validated['details'];
        $product->vendor_id = $id;
        $product->status = "active";
        $product->save();

        return redirect('/vendor-foods')->with('success', 'Item added successfully');
    }

    public function changeStatus(Request $request){
        //dd('got');
        $id = $request->id;
        $status = $request->status;
        $product = Product::find($id)->update(['status' => $status]);
        return \App::make('redirect')->back()->with('success', 'Item Status Changed');
        //return \App::make('redirect')->refresh()->with('success', 'Item Status Changed');
    }
}
