<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LogoutController extends Controller
{
    public function logout(Request $request){
        $request->session()->forget(['email', 'user_type']);
        return redirect('/');
    }

    public function clear(Request $request){
        $request->session()->forget('cart');
        //return redirect('/cart');
        echo "clear";
    }

    public function check(Request $request){
    //     $s = $request->session()->get('shops');
    //     // $key = array_search('Shawarma King', $s);
        
    //     // // dd($s, $key);
    //     // unset($s[0]);
    //     $c = $request->session()->get('cart');
    //     $cc = array_keys($c);
    //     //$key = array_search('Shawarma King', $c);
    //     $key1 = in_array('Pasta', $c[9]);
    //     $key = array_search('Pastaz', array_column($c, 'name'));
    //     dd($s, $c, $key);
    //    //return redirect('/cart');
    dd(session('user_type'));
    }
}
