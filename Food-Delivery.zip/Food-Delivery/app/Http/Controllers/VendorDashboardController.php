<?php

namespace App\Http\Controllers;
use App\Models\Vendor;
use App\Models\Order;
use App\Models\Product;

use Illuminate\Http\Request;

class VendorDashboardController extends Controller
{
    public function index(){
        $email = session()->get('email');
        $vendor = Vendor::where('email', $email)->first();

        $notifications = Notification::where('to', '=', $vendor->shop_name)->where('status', '=', 'New')->count();

        $orders = Order::where('vendor_id', $vendor->id)->count();
        $pending  = Order::where('vendor_id', $vendor->id)->where('status', '=',  'Pending')->count();
        $processing  = Order::where('vendor_id', $vendor->id)->where('status', '=',  'Processing')->count();
        $delivered = Order::where('vendor_id', $vendor->id)->where('status', 'LIKE',  'Delivered%')->count();
        $cancelled = Order::where('vendor_id', $vendor->id)->where('status', 'LIKE',  'Cancelled%')->count();

        $items = Product::where('vendor_id', $vendor->id)->count();
        $active = Product::where('vendor_id', $vendor->id)->where('status', '=',  'active')->count();
        $deactivated = Product::where('vendor_id', $vendor->id)->where('status', '=',  'deactivated')->count();

        $sale = Order::where('vendor_id', $vendor->id)->where('status', 'LIKE',  'Delivered%')->sum('sub_total');

        dd($orders, $pending, $processing, $delivered, $cancelled, $items, $active, $deactivated, $sale);
        
    }
}
