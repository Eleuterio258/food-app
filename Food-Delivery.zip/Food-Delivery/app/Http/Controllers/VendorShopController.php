<?php

namespace App\Http\Controllers;
use App\Models\Vendor;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class VendorShopController extends Controller
{
    public function index(){
        //get vendor id
        $email = session('email');
        $vendor = Vendor::where('email', $email)->first();
        $user = User::where('email', $email)->first();
        
        //dd($vendor->phone);
        return view('vendor.shop', compact('vendor', 'user'));
    }

    public function update(Request $request){

        $email = session('email');
        $vendor = Vendor::where('email', $email)->first();
        $user = User::where('email', $email)->first();
        $vendor_id = $vendor->id;
        $user_id = $user->id;
        //dd($vendor_id);

        $validated = $request->validate([
            'full_name'             =>   'max:255',
            'email'                 =>   "sometimes|required|email|unique:users,email, $user_id" ,
            'phone'                 =>   "sometimes|required|min:7|max:18|unique:users,phone, $user_id"  ,
            'address'               =>   "max:255",
            'shop_name'             =>   "max:100|unique:vendors,shop_name, $vendor_id" ,
            'city'                  =>   "max:50",
            'password'              =>   "sometimes|min:4|max:16",
        ]);        

        //get the image
        $img = $request->image;
        if($img){
            $img_extension = $img->getClientOriginalExtension();
            $img_name = $validated['shop_name'] . '_' .time() . '.' . $img_extension;
            $path = $img->storeAs('images/vendors', $img_name, 'public');

            //delete existing image            
            if($vendor->image){
                Storage::disk('public')->delete($vendor->image);            
            }

            //get vendor id
            $email = session('email');
            //updating data
            $vendor = Vendor::where('email', $email)->update([
                'full_name' => $validated['full_name'],
                'email' => $validated['email'],
                'shop_name' => $validated['shop_name'],
                'phone' => $validated['phone'],
                'address' => $validated['address'],
                'city' => $validated['city'],
                'image' => $path
            ]);
            $user = User::where('email', $email)->update([
                'email' => $validated['email'],
                'phone' => $validated['phone']
            ]);
        } else{
            //get vendor id
            $email = session('email');
            //updating data
            $vendor = Vendor::where('email', $email)->update([
                'full_name' => $validated['full_name'],
                'email' => $validated['email'],
                'shop_name' => $validated['shop_name'],
                'phone' => $validated['phone'],
                'address' => $validated['address'],
                'city' => $validated['city'],
            ]);
            $user = User::where('email', $email)->update([
                'email' => $validated['email'],
                'phone' => $validated['phone']
            ]);
        }
        session([
            'email' => $validated['email']
        ]);

        return \App::make('redirect')->back()->with('success', 'Profile Updated Successfully');

        
    }
}
