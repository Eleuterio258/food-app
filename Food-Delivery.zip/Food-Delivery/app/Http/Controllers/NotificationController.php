<?php

namespace App\Http\Controllers;
use App\Models\Notification;
use App\Models\Vendor;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    public function adminIndex(){
        $notifications = Notification::where('to', '=', 'Admin')->where('status', '=', 'New')->update(['status' => 'Old']);

        $notifications = Notification::where('to', '=', 'Admin')->orderBy('id', 'desc')->paginate(16);
        return view('admin.notifications', compact('notifications'));
    }

    public function vendorIndex(){
        $email = session()->get('email');
        $vendor = Vendor::where('email', $email)->first();

        $notifications = Notification::where('to', '=', $vendor->shop_name)->orderBy('id', 'desc')->paginate(15);

        $change = Notification::where('to', '=', $vendor->shop_name)->where('status', '=', 'New')->update(['status' => 'Old']);

        return view('vendor.notifications', compact('notifications'));
    }


    
}
