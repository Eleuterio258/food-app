<?php

namespace App\Http\Controllers;
use App\Models\User;
use App\Models\Vendor;
use App\Models\Notification;
use Illuminate\Http\Request;

class VendorSignupController extends Controller
{
    public function index(){
        return view('vendor.signup');
    }

    public function signup(Request $request){
        $validated = $request->validate([
            'full_name' => 'required|max:255',
            'email' => 'email|required|unique:users,email',
            'phone' => 'min:7|max:18|required|unique:users,phone',
            'address' => 'required|max:255',
            'shop_name' => 'required|max:100|unique:vendors,shop_name',
            'city' => 'required||max:50',
            'city' => 'required||max:50',
            'password' => 'required|confirmed|min:4|max:16',
            'password_confirmation' => 'required|min:4|max:16',
        ]);

        //dd($request->shop_name);
        
        $user = new User;
        $user->email = $validated['email'];
        $user->password = $validated['password'];
        $user->phone = $validated['phone'];
        $user->user_type = "vendor";
        $user->status = "Pending";
        $user->save();

        $vendor = new Vendor;
        $vendor->email = $validated['email'];
        $vendor->full_name = $validated['full_name'];
        $vendor->phone = $validated['phone'];
        $vendor->shop_name = $validated['shop_name'];
        $vendor->address = $validated['address'];
        $vendor->city = $validated['city'];
        $vendor->country = "Bangladesh";
        $vendor->status = "Pending";
        $vendor->save();

        $notification = new Notification;
        $notification->from = $validated['shop_name'];;
        $notification->to = "Admin";
        $notification->message = "Has has created a new Vendor account, waiting for approval";
        $notification->type = "Account Approval";
        $notification->status = "New";
        $notification->save();

        return redirect('/login')->with('success', 'Registration Successful, we will approve your registration shortly');
    }
}
