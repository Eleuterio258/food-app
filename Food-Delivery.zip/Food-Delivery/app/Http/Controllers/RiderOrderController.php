<?php

namespace App\Http\Controllers;
use App\Models\Rider;
use App\Models\Order;
use Illuminate\Http\Request;

class RiderOrderController extends Controller
{
    public function index(){
        if(!empty($_GET['address'])){
            $newOrders = Order::where('status', 'Processing')->where('address', $_GET['address'])->orderBy('id', 'desc')->get();
        }
        else{
            $newOrders = Order::where('status', 'Processing')->orderBy('id', 'desc')->get();
        }
        $email = session()->get('email');
        $rider = Rider::where('email', $email)->first();
        $name = $rider->full_name;
        
        $pickedOrder = Order::where('status', 'Picked by '. $name)->orderBy('id', 'desc')->get();
        return view('rider.orders', compact('newOrders', 'pickedOrder'));

    }

    public function order($id){
        $order = Order::find($id);
        return view('rider.order', compact('order'));

    }

    public function riderAccept($id){
        $email = session()->get('email');
        $rider = Rider::where('email', $email)->first();
        //$name = $rider->name;

        $order = Order::find($id)->update([
            'status' => 'Picked by ' . $rider->full_name
        ]);
        return \App::make('redirect')->back()->with('success', 'Order Accepted Successfully');
        
    }

    public function deliver(Request $request){
        $email = session()->get('email');
        $rider = Rider::where('email', $email)->first();

        $validated = $request->validate([
            'code' => "required|numeric|min:4"
        ]);

        $order_id = $request->route()->parameter('id');
        $order = Order::find($order_id);
        $code = $order->code;

        if($code == $validated['code']){
            $order->status = "Delivered by " . $rider->full_name;
            $order->code = NULL;
            $order->save();
            return \App::make('redirect')->back()->with('success', 'Order Delivered Successfully');
        } else{
            return \App::make('redirect')->back()->with('error', 'Code does not match');
        }
    }

    public function orderHistory(){
        $email = session()->get('email');
        $rider = Rider::where('email', $email)->first();

        $orders = Order::where('status', 'Delivered by '. $rider->full_name)->get();
        return view('rider.history', compact('orders'));
    }
}
