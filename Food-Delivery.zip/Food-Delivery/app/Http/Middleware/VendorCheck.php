<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class VendorCheck
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        if($request->session()->has('user_type')){
            if(session('user_type') != 'vendor'){
                return redirect('/');
            }
        } else{
            return redirect('/login')->with('message', 'You must be logged in');
        }
        return $next($request);
    }
}
